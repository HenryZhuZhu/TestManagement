# -*- coding: utf-8 -*-
"""Generate iTest 智能排测系统 汇报.pptx — Apple-style deck (16:9)."""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn

# ---------- palette (from Design.md) ----------
BG      = RGBColor(0xFB, 0xFB, 0xFD)
INK     = RGBColor(0x1D, 0x1D, 0x1F)
MUTED   = RGBColor(0x86, 0x86, 0x8B)
ACCENT  = RGBColor(0x00, 0x71, 0xE3)
INDIGO  = RGBColor(0x5E, 0x5C, 0xE6)
PURPLE  = RGBColor(0xAF, 0x52, 0xDE)
GREEN   = RGBColor(0x2A, 0x9E, 0x44)
ORANGE  = RGBColor(0xEE, 0x7A, 0x00)
RED     = RGBColor(0xD9, 0x30, 0x2A)
CARD    = RGBColor(0xFF, 0xFF, 0xFF)
SURF2   = RGBColor(0xF0, 0xF0, 0xF3)
LINE    = RGBColor(0xE2, 0xE2, 0xE6)
WHITE   = RGBColor(0xFF, 0xFF, 0xFF)

FONT = "Microsoft YaHei"      # 中文友好；PowerPoint 会回退到可用字体

prs = Presentation()
prs.slide_width  = Inches(13.333)
prs.slide_height = Inches(7.5)
SW, SH = prs.slide_width, prs.slide_height
BLANK = prs.slide_layouts[6]


def slide(bg=BG):
    s = prs.slides.add_slide(BLANK)
    r = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SW, SH)
    r.fill.solid(); r.fill.fore_color.rgb = bg
    r.line.fill.background()
    r.shadow.inherit = False
    r._element.addprevious(r._element)  # keep at back
    return s


def _set_anchor(tf, anchor):
    if anchor:
        tf.vertical_anchor = anchor


def text(s, x, y, w, h, runs, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP,
         line_spacing=1.1, space_after=6):
    """runs: list of (text, size, color, bold) ; each becomes a paragraph."""
    tb = s.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    _set_anchor(tf, anchor)
    tf.margin_left = tf.margin_right = Pt(0)
    tf.margin_top = tf.margin_bottom = Pt(0)
    first = True
    for item in runs:
        txt, size, color, bold = item
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = align
        p.line_spacing = line_spacing
        p.space_after = Pt(space_after)
        p.space_before = Pt(0)
        r = p.add_run(); r.text = txt
        f = r.font
        f.size = Pt(size); f.bold = bold
        f.color.rgb = color; f.name = FONT
    return tb


def rect(s, x, y, w, h, fill=CARD, line=LINE, line_w=1.0, radius=True, shadow=False):
    shp = s.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE, x, y, w, h)
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid(); shp.fill.fore_color.rgb = fill
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line; shp.line.width = Pt(line_w)
    shp.shadow.inherit = False
    if radius:
        try:
            shp.adjustments[0] = 0.06
        except Exception:
            pass
    return shp


def chip(s, x, y, w, h, label, color):
    c = rect(s, x, y, w, h, fill=None, line=None)
    bar = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    bar.fill.solid(); bar.fill.fore_color.rgb = color
    bar.line.fill.background(); bar.shadow.inherit = False
    try: bar.adjustments[0] = 0.5
    except Exception: pass
    tf = bar.text_frame; tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
    r = p.add_run(); r.text = label
    r.font.size = Pt(11); r.font.bold = True; r.font.color.rgb = WHITE; r.font.name = FONT
    return bar


def eyebrow(s, x, y, txt, color=ACCENT):
    text(s, x, y, Inches(8), Inches(0.4), [(txt, 13, color, True)])


def pagenum(s, n):
    text(s, SW - Inches(1.1), SH - Inches(0.55), Inches(0.8), Inches(0.35),
         [(f"{n:02d}", 11, MUTED, False)], align=PP_ALIGN.RIGHT)


def footer_brand(s):
    text(s, Inches(0.6), SH - Inches(0.55), Inches(6), Inches(0.35),
         [("iTest 智能排测系统", 11, MUTED, False)])


MX = Inches(0.9)   # left margin
CW = SW - Inches(1.8)  # content width

# ============================================================
# 1 · 封面
# ============================================================
s = slide()
# accent band
band = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SW, Inches(0.18))
band.fill.solid(); band.fill.fore_color.rgb = ACCENT; band.line.fill.background(); band.shadow.inherit = False
eyebrow(s, MX, Inches(1.5), "SMART SCHEDULING FOR ENGINEERING TEST LABS")
text(s, MX, Inches(2.0), Inches(11), Inches(2.2),
     [("iTest 智能排测系统", 54, INK, True),
      ("一次预约，自动排测，完成提醒。", 26, ACCENT, True)],
     line_spacing=1.05, space_after=14)
text(s, MX, Inches(4.5), Inches(11), Inches(1.2),
     [("面向工程实验机台的智能排测平台 —— 让机台不被空占、用尽其用。", 18, MUTED, False)])
text(s, MX, Inches(6.4), Inches(11), Inches(0.6),
     [("参赛项目汇报   ·   汇报人 / 团队   ·   日期", 14, MUTED, False)])
pagenum(s, 1)

# ============================================================
# 2 · 价值主张
# ============================================================
s = slide()
eyebrow(s, MX, Inches(0.7), "价值主张")
text(s, MX, Inches(1.3), CW, Inches(1.6),
     [("一句话：", 22, MUTED, False),
      ("工程师下班前预约一次，系统自动排测、完成提醒。", 34, INK, True)],
     line_spacing=1.1, space_after=10)
steps = [("🗓️  预约", "选机台/时间，配额校验", ACCENT),
         ("⚙️  自动排测", "白班自测 / 夜班算法+Lab 代测", INDIGO),
         ("🔔  完成提醒", "测完主动通知，次日看结果", GREEN)]
cw = Inches(3.7); gap = Inches(0.45); x = MX; y = Inches(3.6); h = Inches(2.4)
for i, (t, d, col) in enumerate(steps):
    cx = x + i * (cw + gap)
    rect(s, cx, y, cw, h, fill=CARD, line=LINE)
    bar = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, cx, y, Inches(0.12), h)
    bar.fill.solid(); bar.fill.fore_color.rgb = col; bar.line.fill.background(); bar.shadow.inherit = False
    text(s, cx + Inches(0.35), y + Inches(0.35), cw - Inches(0.6), Inches(1.8),
         [(t, 22, INK, True), (d, 14, MUTED, False)], line_spacing=1.15, space_after=10)
    if i < 2:
        text(s, cx + cw - Inches(0.05), y + Inches(0.85), gap, Inches(0.6),
             [("→", 24, MUTED, True)], align=PP_ALIGN.CENTER)
footer_brand(s); pagenum(s, 2)

# ============================================================
# 3 · 背景与痛点
# ============================================================
s = slide()
eyebrow(s, MX, Inches(0.7), "背景")
text(s, MX, Inches(1.15), CW, Inches(0.9), [("机台为什么这么紧张", 32, INK, True)])
text(s, MX, Inches(2.0), CW, Inches(0.5),
     [("不是机台不够，是机台被空占着不够。", 16, MUTED, False)])
pains = [("机台浪费", "提前 3 天占住机台，别的部门当天借不到", RED),
         ("使用率低", "难估时长，按整段占机估算，机台空挂", ORANGE),
         ("信息不透明", "谁在用、用到几点，没人说得清", ACCENT),
         ("流程繁琐", "占机后还要撤单、再重填实际信息", PURPLE)]
cw = Inches(2.75); gap = Inches(0.3); x = MX; y = Inches(3.1); h = Inches(2.7)
for i, (t, d, col) in enumerate(pains):
    cx = x + i * (cw + gap)
    rect(s, cx, y, cw, h, fill=CARD, line=LINE)
    dot = s.shapes.add_shape(MSO_SHAPE.OVAL, cx + Inches(0.3), y + Inches(0.35), Inches(0.4), Inches(0.4))
    dot.fill.solid(); dot.fill.fore_color.rgb = col; dot.line.fill.background(); dot.shadow.inherit = False
    text(s, cx + Inches(0.3), y + Inches(1.0), cw - Inches(0.55), Inches(1.5),
         [(t, 19, INK, True), (d, 13, MUTED, False)], line_spacing=1.2, space_after=8)
footer_brand(s); pagenum(s, 3)

# ============================================================
# 4 · Before / After（重点）
# ============================================================
s = slide()
eyebrow(s, MX, Inches(0.55), "全场重点")
text(s, MX, Inches(1.0), CW, Inches(0.8), [("Before  →  After", 32, INK, True)])
rows = [
    ("借机方式", "人去抢、提前 3 天占", "按规则预约 / 算法分配"),
    ("时间估算", "按整段占机估，越占越多", "按预估时长切窗 + 配额封顶"),
    ("占住不用", "没人管，长期空挂", "到点不签到→自动释放+候补补位"),
    ("夜间/节假日", "协调靠人盯", "算法统一排程 + Lab 代测"),
    ("信息透明", "黑盒", "实时甘特看板，一目了然"),
    ("工程师体验", "抢机+盯机+撤单重填", "预约一次，自动测试+完成提醒"),
]
top = Inches(2.0); rh = Inches(0.78)
col0 = MX; w0 = Inches(2.2)
colB = MX + w0 + Inches(0.1); wB = Inches(4.4)
colA = colB + wB + Inches(0.2); wA = Inches(4.4)
# headers
chip(s, colB, top - Inches(0.05), wB, Inches(0.5), "❌  BEFORE  占机模式", RED)
chip(s, colA, top - Inches(0.05), wA, Inches(0.5), "✅  AFTER  智能排测", GREEN)
y = top + Inches(0.6)
for i, (k, b, a) in enumerate(rows):
    if i % 2 == 0:
        rect(s, col0, y, w0 + Inches(0.1) + wB + Inches(0.2) + wA, rh - Inches(0.06),
             fill=SURF2, line=None, radius=False)
    text(s, col0 + Inches(0.1), y, w0, rh, [(k, 14, INK, True)], anchor=MSO_ANCHOR.MIDDLE)
    text(s, colB + Inches(0.15), y, wB - Inches(0.3), rh, [(b, 14, RED, False)], anchor=MSO_ANCHOR.MIDDLE)
    text(s, colA + Inches(0.15), y, wA - Inches(0.3), rh, [(a, 14, GREEN, False)], anchor=MSO_ANCHOR.MIDDLE)
    y += rh
footer_brand(s); pagenum(s, 4)

# ============================================================
# 5 · 解决思路：调度权 / 执行权拆分
# ============================================================
s = slide()
eyebrow(s, MX, Inches(0.7), "解决思路")
text(s, MX, Inches(1.15), CW, Inches(0.9), [("一个关键拆分：调度权 ÷ 执行权", 30, INK, True)])
# two big cards
cw = Inches(5.6); gap = Inches(0.6); y = Inches(2.3); h = Inches(2.0)
c1 = MX
rect(s, c1, y, cw, h, fill=CARD, line=LINE)
text(s, c1 + Inches(0.4), y + Inches(0.35), cw - Inches(0.8), h - Inches(0.6),
     [("调度权 = 系统 / 算法", 22, ACCENT, True),
      ("谁决定机台和时间 —— 永远归系统。这是治理占机的关键。", 14, MUTED, False)],
     line_spacing=1.2, space_after=10)
c2 = MX + cw + gap
rect(s, c2, y, cw, h, fill=CARD, line=LINE)
text(s, c2 + Inches(0.4), y + Inches(0.35), cw - Inches(0.8), h - Inches(0.6),
     [("执行权 = 按时段分", 22, INDIGO, True),
      ("白班工程师自己测（保留习惯）；夜班/节假日交给算法排、Lab 代测。", 14, MUTED, False)],
     line_spacing=1.2, space_after=10)
# three-mode band
y2 = Inches(4.8); h2 = Inches(1.5)
modes = [("工作日白班 08–20", "自助预约 + 护栏", "PE 自己测", ORANGE),
         ("工作日夜班 20–08", "智能算法排程", "Lab 代测", INDIGO),
         ("节假日 全天", "智能算法排程", "Lab 代测", PURPLE)]
mw = Inches(3.7); mg = Inches(0.45)
for i, (a, b, c, col) in enumerate(modes):
    mx = MX + i * (mw + mg)
    rect(s, mx, y2, mw, h2, fill=SURF2, line=LINE)
    bar = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, mx, y2, mw, Inches(0.12))
    bar.fill.solid(); bar.fill.fore_color.rgb = col; bar.line.fill.background(); bar.shadow.inherit = False
    text(s, mx + Inches(0.3), y2 + Inches(0.3), mw - Inches(0.6), h2 - Inches(0.4),
         [(a, 16, INK, True), (b, 13, INK, False), (c, 12, MUTED, False)],
         line_spacing=1.15, space_after=5)
footer_brand(s); pagenum(s, 5)

# ============================================================
# 6 · 主线演示：PE 工程师的一天
# ============================================================
s = slide()
eyebrow(s, MX, Inches(0.55), "★ 主线演示")
text(s, MX, Inches(1.0), CW, Inches(0.8), [("一个 PE 工程师的一天", 32, INK, True)])
steps = [
    ("17:30 下班前", "① 预约一次", "选机台/时间，配额校验，\n“预约成功·待签到”", ACCENT),
    ("夜间 20:00–08:00", "② 自动代测", "算法排好空档，\nLab 按机台执行", INDIGO),
    ("测试结束", "③ 完成提醒", "状态变“已完成”，\n🔔 主动推送通知", GREEN),
    ("次日 09:00", "④ 看结果分析", "工作台待办：\n已完成·可分析", PURPLE),
]
cw = Inches(2.78); gap = Inches(0.25); y = Inches(2.4); h = Inches(3.2)
for i, (tt, hd, dd, col) in enumerate(steps):
    cx = MX + i * (cw + gap)
    rect(s, cx, y, cw, h, fill=CARD, line=LINE)
    chip(s, cx + Inches(0.25), y + Inches(0.3), Inches(2.2), Inches(0.42), tt, col)
    text(s, cx + Inches(0.3), y + Inches(1.0), cw - Inches(0.55), h - Inches(1.2),
         [(hd, 19, INK, True), (dd, 13, MUTED, False)], line_spacing=1.25, space_after=10)
    if i < 3:
        text(s, cx + cw - Inches(0.02), y + Inches(1.3), gap + Inches(0.1), Inches(0.6),
             [("→", 20, MUTED, True)], align=PP_ALIGN.CENTER)
text(s, MX, Inches(5.95), CW, Inches(0.6),
     [("“工程师的夜晚还给他，机台的夜晚交给系统。”", 16, ACCENT, True)], align=PP_ALIGN.CENTER)
# demo hint
text(s, MX, Inches(6.55), CW, Inches(0.4),
     [("演示：apply → schedule → lab-engineer → workspace（见《汇报演讲.md》附录 A 录制清单）", 11, MUTED, False)],
     align=PP_ALIGN.CENTER)
pagenum(s, 6)

# ============================================================
# 7 · 三个角色
# ============================================================
s = slide()
eyebrow(s, MX, Inches(0.7), "三个角色，一套系统")
text(s, MX, Inches(1.15), CW, Inches(0.8), [("页面按业务域组织，角色只是过滤器", 28, INK, True)])
roles = [("PE 工程师", "预约 / 提交、看甘特、签到、跟踪结果", ACCENT),
         ("PE 管理者", "团队总表、每日一次关键提优、看运营数据", PURPLE),
         ("Lab 工程师", "夜测按机台执行、改派、反馈、维护机台与配置", GREEN)]
cw = Inches(3.7); gap = Inches(0.45); y = Inches(2.5); h = Inches(2.8)
for i, (t, d, col) in enumerate(roles):
    cx = MX + i * (cw + gap)
    rect(s, cx, y, cw, h, fill=CARD, line=LINE)
    dot = s.shapes.add_shape(MSO_SHAPE.OVAL, cx + Inches(0.35), y + Inches(0.4), Inches(0.45), Inches(0.45))
    dot.fill.solid(); dot.fill.fore_color.rgb = col; dot.line.fill.background(); dot.shadow.inherit = False
    text(s, cx + Inches(0.35), y + Inches(1.1), cw - Inches(0.7), h - Inches(1.3),
         [(t, 21, INK, True), (d, 14, MUTED, False)], line_spacing=1.25, space_after=8)
footer_brand(s); pagenum(s, 7)

# ============================================================
# 8 · 反占机四道护栏
# ============================================================
s = slide()
eyebrow(s, MX, Inches(0.7), "治理恶性占机")
text(s, MX, Inches(1.15), CW, Inches(0.8), [("四道护栏，让“占着不用”无利可图", 28, INK, True)])
guards = [("签到 + 超时释放", "占了不来就自动收回，候补顺延", ACCENT),
          ("部门配额封顶", "每日机时上限，仅白班计，防垄断", ORANGE),
          ("候补自动补位", "机台一空出，排队任务即补上", GREEN),
          ("预约提前量限制", "只能约 当天 ~ 提前 3 天内", INDIGO)]
cw = Inches(5.6); gap = Inches(0.6); ch_ = Inches(1.7)
for i, (t, d, col) in enumerate(guards):
    cx = MX + (i % 2) * (cw + gap)
    cy = Inches(2.4) + (i // 2) * (ch_ + Inches(0.35))
    rect(s, cx, cy, cw, ch_, fill=CARD, line=LINE)
    bar = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, cx, cy, Inches(0.12), ch_)
    bar.fill.solid(); bar.fill.fore_color.rgb = col; bar.line.fill.background(); bar.shadow.inherit = False
    text(s, cx + Inches(0.4), cy + Inches(0.3), cw - Inches(0.7), ch_ - Inches(0.5),
         [(t, 19, INK, True), (d, 14, MUTED, False)], line_spacing=1.2, space_after=8)
text(s, MX, Inches(6.35), CW, Inches(0.5),
     [("＋ 二期“信用分”：估时越准、爽约越少，下次越优先。", 14, MUTED, True)])
footer_brand(s); pagenum(s, 8)

# ============================================================
# 9 · 价值与收益
# ============================================================
s = slide()
eyebrow(s, MX, Inches(0.7), "看得见的价值")
text(s, MX, Inches(1.15), CW, Inches(0.8), [("从“拍脑袋协调”到“看数据决策”", 28, INK, True)])
kpis = [("机台综合利用率", "↑ 20–30%", "空窗回收 + 紧凑切窗", GREEN),
        ("case 完成率", "↑", "夜测按时完成率提升", ACCENT),
        ("恶性占机", "↓", "爽约/空挂显著下降", ORANGE)]
cw = Inches(3.7); gap = Inches(0.45); y = Inches(2.5); h = Inches(2.6)
for i, (t, big, d, col) in enumerate(kpis):
    cx = MX + i * (cw + gap)
    rect(s, cx, y, cw, h, fill=CARD, line=LINE)
    text(s, cx + Inches(0.35), y + Inches(0.35), cw - Inches(0.7), Inches(0.5),
         [(t, 14, MUTED, True)])
    text(s, cx + Inches(0.35), y + Inches(0.85), cw - Inches(0.7), Inches(1.0),
         [(big, 40, col, True)])
    text(s, cx + Inches(0.35), y + Inches(1.85), cw - Inches(0.7), Inches(0.6),
         [(d, 13, MUTED, False)])
text(s, MX, Inches(5.5), CW, Inches(0.5),
     [("注：以上为原型测算 / 目标值，落地后以试点实际数据为准。", 12, MUTED, False)])
footer_brand(s); pagenum(s, 9)

# ============================================================
# 10 · 可信度：已经做到哪一步
# ============================================================
s = slide()
eyebrow(s, MX, Inches(0.7), "可落地性")
text(s, MX, Inches(1.15), CW, Inches(0.8), [("不是概念，是可点可用的系统", 28, INK, True)])
items = [("可交互原型已完成", "六大业务域 + 三角色工作面，甘特/预约/签到/配额/借机规则/运营分析全可用", ACCENT),
         ("产品与研发文档齐备", "产品设计 · PRD（数据模型+接口）· 设计规范 均已成文", INDIGO),
         ("低成本落地", "前端纯静态 + 标准 REST 接口设计，后端对接即可", GREEN)]
y = Inches(2.4); h = Inches(1.2)
for i, (t, d, col) in enumerate(items):
    cy = y + i * (h + Inches(0.25))
    rect(s, MX, cy, CW, h, fill=CARD, line=LINE)
    dot = s.shapes.add_shape(MSO_SHAPE.OVAL, MX + Inches(0.4), cy + Inches(0.4), Inches(0.35), Inches(0.35))
    dot.fill.solid(); dot.fill.fore_color.rgb = col; dot.line.fill.background(); dot.shadow.inherit = False
    text(s, MX + Inches(1.1), cy + Inches(0.22), CW - Inches(1.4), h - Inches(0.3),
         [(t, 18, INK, True), (d, 13, MUTED, False)], line_spacing=1.15, space_after=4)
text(s, MX, Inches(6.4), CW, Inches(0.5),
     [("“今天演示的每一个画面，都是真实可点的系统，不是效果图。”", 15, ACCENT, True)], align=PP_ALIGN.CENTER)
pagenum(s, 10)

# ============================================================
# 11 · 规划展望
# ============================================================
s = slide()
eyebrow(s, MX, Inches(0.7), "规划与展望")
text(s, MX, Inches(1.15), CW, Inches(0.8), [("从“排好测试”到“越用越聪明”", 28, INK, True)])
phase = [("一期 · 已落地", ["两模式排测（白班自助 / 夜班·节假日算法）",
                           "反占机四道护栏 + 运营分析看板",
                           "三角色协同 · 借机规则周历"], GREEN),
         ("二期 · 进行中", ["信用分体系（数据已埋点）",
                           "估时智能推荐 · IM 完成提醒/审批打通",
                           "多实验室 / 多区机台扩展"], ACCENT)]
cw = Inches(5.6); gap = Inches(0.6); y = Inches(2.4); h = Inches(3.2)
for i, (t, lst, col) in enumerate(phase):
    cx = MX + i * (cw + gap)
    rect(s, cx, y, cw, h, fill=CARD, line=LINE)
    chip(s, cx + Inches(0.35), y + Inches(0.35), Inches(2.4), Inches(0.45), t, col)
    runs = [("• " + x, 15, INK, False) for x in lst]
    text(s, cx + Inches(0.4), y + Inches(1.15), cw - Inches(0.8), h - Inches(1.4),
         runs, line_spacing=1.2, space_after=12)
footer_brand(s); pagenum(s, 11)

# ============================================================
# 12 · 结语
# ============================================================
s = slide()
band = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, SH - Inches(0.18), SW, Inches(0.18))
band.fill.solid(); band.fill.fore_color.rgb = ACCENT; band.line.fill.background(); band.shadow.inherit = False
text(s, MX, Inches(2.4), CW, Inches(1.6),
     [("一次预约，自动排测，完成提醒。", 40, INK, True)], align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
text(s, MX, Inches(4.0), CW, Inches(0.8),
     [("把工程师从抢机台里解放出来，把机台资源真正用满。", 18, MUTED, False)], align=PP_ALIGN.CENTER)
text(s, MX, Inches(5.4), CW, Inches(0.6),
     [("iTest 智能排测系统   ·   谢谢聆听", 16, ACCENT, True)], align=PP_ALIGN.CENTER)
pagenum(s, 12)

out = "iTest智能排测系统_汇报.pptx"
prs.save(out)
print("saved:", out, "slides:", len(prs.slides._sldIdLst))
