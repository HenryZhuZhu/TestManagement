# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

A **client-side interactive prototype** of "iTest 智能排测系统" — an intelligent test-machine scheduling system for engineering labs. It is **not** a build-tooled app: there is no package.json, bundler, framework, or test suite. Pages are plain static HTML + vanilla JS + one shared CSS file, opened directly in a browser (`file://`). All state lives in browser `localStorage`. UI copy is Chinese.

`PRD.md` is the authoritative product spec (roles, flows, field dictionary, API/data-model recommendations for a future real backend). `Design.md` is the visual/interaction design system the UI must follow.

## Running & checking

```bash
open index.html                 # macOS: open the prototype in the default browser

# Syntax-check shared JS (no test runner exists):
node --check assets/data.js
node --check assets/app.js

# Syntax-check an inline page <script> block:
node -e 'const fs=require("fs"),vm=require("vm");const h=fs.readFileSync(process.argv[1],"utf8");
const re=/<script>([\s\S]*?)<\/script>/g;let m,last;while((m=re.exec(h)))last=m[1];new vm.Script(last);console.log("OK")' pe-engineer.html
```

There is no lint/build/test step. "Verification" = syntax-check the JS and open the page in a browser.

## Architecture

Three shared assets are loaded by **every** page (in this order — `data.js` before `app.js`), then each page has an inline `<script>` for page-specific logic:

- **`assets/data.js`** → `window.Store`. The single source of truth: seed mock data (machines, tasks, meta), `localStorage` persistence, and all mutations. **Every state change must go through a `Store` method** (`addTask`, `updateTask`, `removeTask`, `setTaskStatus`, `setTaskMachine`, `setTaskPrio`, `setMachineStatus`, `autoSchedule`, `useManagerAdjust`) so it persists. Also exposes formatters/enums: `minToClock`, `fmtDur`, `dateLabel`, `dayName`, `STATUS_META`, `MACHINE_STATUS`, `PRIO_META`, `SHIFT_RANGE`, `CURRENT_PE`.
- **`assets/app.js`** → `window.App`. Shared UI: `mountChrome(activePage, rolePill)` (header+theme+reset), `mountFooter()`, `mountFab(href,label)`, `renderGantt(mountEl, opts)`, `taskDetailHTML(task)`, `modal({title,sub,body,foot})` (returns `{el, close}`), `toast(msg, kind)`, `initReveal()`, and `ICON` (inline SVG strings).
- **`assets/styles.css`** → implements `Design.md`: CSS-variable tokens, light/dark via `html.dark`, all components (cards, gantt, badges, modal, forms, m-group). **Use the existing tokens/classes; do not hardcode colors.**

Pages: `index.html` (portal), `new-application.html` (submit form — deliberately **not** in the top nav), `pe-engineer.html`, `pe-manager.html`, `lab-engineer.html`, `machines.html`. The top-nav list is the `NAV` array in `app.js`.

### Time model (critical — get this right)
Gantt timeline = one day = **1440 min**, `offset 0 = 08:00`. Task `start`/`end` are minute-offsets from 08:00 (09:00→60, 20:00→720). Shifts: `day = [0,720)` (08:00–20:00), `night = [720,1440)` (20:00–08:00) — see `Store.SHIFT_RANGE`. `Store.minToClock(offset)` converts back. Tasks also carry `day` (0=today, 1=tomorrow, -1=yesterday); a simulated "now" is `Store.nowMin()` (currently 400 = 14:40) and the gantt "now" line only renders when `day === 0`.

### The scheduling engine
`Store.autoSchedule(id)` is the "intelligent scheduler": releases the task's current placement, then greedily finds the earliest free slot on a `schedulable` machine within the task's shift/day window (day-shift today never schedules before `nowMin`). This is intentionally re-run on **submit and on every edit** — the product requirement is that engineers can never pin a machine/time, which prevents the "pre-occupy a machine" pain point. Preserve this behavior when editing scheduling logic.

### Domain rules baked into the data
- `MACHINE_STATUS[status].schedulable` (idle/running = true; maintenance/fault = false) decides which machines `autoSchedule` and `schedulableMachines()` consider. Setting a machine to fault/maintenance excludes it; its already-placed tasks are **not** auto-migrated (Lab reassigns them manually).
- Task statuses (`STATUS_META`): pending → scheduled → running → done/fail/hold. PE-editable only when `pending`/`scheduled`.
- PE manager has a once-per-day priority bump tracked by `meta.managerAdjustUsed` / `managerAdjustTask`.
- Night list on the Lab page is grouped by machine; intra-group order uses the task `ord` field; reassignment sets `moved = true`.

### Conventions
- Bumping the seed schema: change `KEY` in `data.js` (currently `itest-state-v2`) so cached `localStorage` is invalidated; otherwise returning users keep stale data.
- The logged-in PE is the `Store.CURRENT_PE` constant (`'王伟'`) — used by the "我的" filter and ownership checks. There is no real auth.
- Reference clickable file links and time/status via the shared `Store` formatters and `App.ICON` SVGs rather than re-inventing them.
