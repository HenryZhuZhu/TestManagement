/* ============================================================
   iTest 智能排测系统 — shared mock data + state layer
   Persisted to localStorage so edits flow across pages.
   Time model: timeline offset 0 = 08:00; 1440 min span = 08:00→next 08:00
     Day shift   白班 : offset    0 – 720   (08:00 – 20:00)
     Night shift 夜班 : offset  720 – 1440  (20:00 – 08:00)
   ============================================================ */
(function (global) {
  const KEY = 'itest-state-v7';

  // simulated "current time": 14:40 → day shift in progress
  const NOW_MIN = 400;

  // 中国大陆法定节假日日历（2026，自动同步，无需人工维护）
  const CN_HOLIDAYS = [
    '2026-01-01',                                                                                       // 元旦
    '2026-02-16','2026-02-17','2026-02-18','2026-02-19','2026-02-20','2026-02-21','2026-02-22',         // 春节
    '2026-04-04','2026-04-05','2026-04-06',                                                             // 清明
    '2026-05-01','2026-05-02','2026-05-03','2026-05-04','2026-05-05',                                   // 劳动节
    '2026-06-19','2026-06-20','2026-06-21',                                                             // 端午
    '2026-09-25','2026-09-26','2026-09-27',                                                             // 中秋
    '2026-10-01','2026-10-02','2026-10-03','2026-10-04','2026-10-05','2026-10-06','2026-10-07','2026-10-08', // 国庆
  ];
  // 调休上班日（落在周末但需上班）
  const CN_MAKEUP_WORKDAYS = ['2026-02-14', '2026-02-15', '2026-04-26', '2026-10-10'];

  const SEED = {
    nowMin: NOW_MIN,
    today: '2026-06-10',
    meta: {
      // PE manager: one priority bump per day, for a single task
      managerAdjustUsed: false,
      managerAdjustTask: null,
      noShowToday: 1,          // 白班未签到被自动释放次数（恶性占机治理埋点）
      autoReleased: ['T-1009'],
    },
    // 部门：优先级(rank 越小越高) + 每日白班机时配额(分钟，仅白天计)
    departments: [
      { name: '研发一部', rank: 1, dailyQuotaMin: 600 },
      { name: '研发二部', rank: 2, dailyQuotaMin: 480 },
      { name: '研发三部', rank: 3, dailyQuotaMin: 360 },
    ],
    config: { checkinGraceMin: 15, leadDays: 3 },   // 签到宽限期 / 预约提前量(当天~T+3)
    // 借机规则：周一至周五 × 机台 的「优先预约部门」单元格（Lab 维护，不定期更新）
    // 每条 = 一个 (机台, 星期) 单元格，depts 为该格拥有优先权的部门集合（可多个共享）。
    borrowRules: [
      { id: 'BR-1',  machine: 'ICT-A',   weekday: '周一', depts: ['研发一部'],          note: '主板 ICT 量产优先窗口' },
      { id: 'BR-2',  machine: 'ICT-A',   weekday: '周二', depts: ['研发一部','研发二部'], note: '两部门共享，按部门优先级排队' },
      { id: 'BR-3',  machine: 'ICT-A',   weekday: '周三', depts: ['研发二部'],          note: '' },
      { id: 'BR-4',  machine: 'ICT-A',   weekday: '周四', depts: ['研发二部'],          note: '' },
      { id: 'BR-5',  machine: 'ICT-A',   weekday: '周五', depts: ['研发三部'],          note: '周末前补测' },
      { id: 'BR-6',  machine: 'ICT-B',   weekday: '周一', depts: ['研发一部'],          note: '' },
      { id: 'BR-7',  machine: 'ICT-B',   weekday: '周二', depts: ['研发二部'],          note: '' },
      { id: 'BR-8',  machine: 'ICT-B',   weekday: '周三', depts: ['研发一部','研发三部'], note: '' },
      { id: 'BR-9',  machine: 'ICT-B',   weekday: '周五', depts: ['研发一部'],          note: '' },
      { id: 'BR-10', machine: 'FCT-A',   weekday: '周一', depts: ['研发一部','研发三部'], note: '共享窗口' },
      { id: 'BR-11', machine: 'FCT-A',   weekday: '周二', depts: ['研发三部'],          note: '整机功能测试' },
      { id: 'BR-12', machine: 'FCT-A',   weekday: '周四', depts: ['研发二部'],          note: '' },
      { id: 'BR-13', machine: 'FCT-A',   weekday: '周五', depts: ['研发二部'],          note: '' },
      { id: 'BR-14', machine: 'FCT-B',   weekday: '周二', depts: ['研发二部'],          note: '' },
      { id: 'BR-15', machine: 'RF-01',   weekday: '周一', depts: ['研发三部'],          note: '周一上午校准，期间不可约' },
      { id: 'BR-16', machine: 'RF-01',   weekday: '周二', depts: ['研发三部'],          note: '' },
      { id: 'BR-17', machine: 'RF-01',   weekday: '周三', depts: ['研发一部','研发二部','研发三部'], note: '射频公共窗口，三部门共享' },
      { id: 'BR-18', machine: 'RF-01',   weekday: '周四', depts: ['研发一部'],          note: '' },
      { id: 'BR-19', machine: 'BURN-01', weekday: '周一', depts: ['研发二部'],          note: '' },
      { id: 'BR-20', machine: 'BURN-01', weekday: '周四', depts: ['研发一部'],          note: '老化测试排程' },
      { id: 'BR-21', machine: 'BURN-01', weekday: '周五', depts: ['研发三部'],          note: '' },
    ],
    // 机台零部件 / 治具说明：供 PE 预约前参考（Lab 维护，不定期更新）
    machineParts: [
      { id: 'MP-1', machine: 'ICT-A',   part: '飞针探针卡 Probe-A',         spec: 'Apollo / Orion 主板（≤ 6 层）', note: '探针寿命约 80%，大批量测试前建议更换' },
      { id: 'MP-2', machine: 'ICT-B',   part: '针床治具 Bed-of-Nails B2',   spec: 'Vega 子板',                    note: '仅支持 1.27mm 间距测试点' },
      { id: 'MP-3', machine: 'FCT-A',   part: '功能夹具 FX-12 + 24V 负载',  spec: 'Nova 整机 / Orion 模组',        note: '需配 24V 电源模块' },
      { id: 'MP-4', machine: 'FCT-B',   part: '探针更换中',                 spec: '—',                            note: '保养中，预计 18:00 恢复' },
      { id: 'MP-5', machine: 'RF-01',   part: '射频屏蔽箱 + 矢网校准件',     spec: 'Pulsar 射频板（Sub-6GHz）',     note: '每周一上午校准，校准期间不可预约' },
      { id: 'MP-6', machine: 'BURN-01', part: '高低温老化箱 + 温度探头 ×8', spec: 'Quasar 电源板',                 note: '压缩机故障维修中，暂停排测' },
    ],
    machines: [
      { id: 'M-01', name: 'ICT-A',  type: 'ICT 在线测试',  lab: 'A区·01', status: 'idle',        owner: '—',        note: '' },
      { id: 'M-02', name: 'ICT-B',  type: 'ICT 在线测试',  lab: 'A区·02', status: 'running',     owner: '陈明',     note: '正在执行 T-1004' },
      { id: 'M-03', name: 'FCT-A',  type: 'FCT 功能测试',  lab: 'A区·05', status: 'running',     owner: '王伟',     note: '正在执行 T-1006' },
      { id: 'M-04', name: 'FCT-B',  type: 'FCT 功能测试',  lab: 'A区·06', status: 'maintenance', owner: '设备组',   note: '探针更换保养，预计 18:00 恢复' },
      { id: 'M-05', name: 'RF-01',  type: '射频测试',      lab: 'B区·11', status: 'idle',        owner: '—',        note: '' },
      { id: 'M-06', name: 'BURN-01',type: '老化测试',      lab: 'B区·14', status: 'fault',       owner: '设备组',   note: '温箱压缩机异常，待维修，暂停排测' },
    ],
    tasks: [
      // ---------- 白班 day shift ----------
      { id: 'T-1001', shift: 'day',   machine: 'M-01', start: 0,   end: 120, status: 'done',
        pe: '王伟', dept: '研发一部', product: 'Apollo 主板', type: 'ICT', prio: 'mid', est: 120, note: '良率 99.2%，已上传报告' },
      { id: 'T-1002', shift: 'day',   machine: 'M-01', start: 150, end: 330, status: 'done',
        pe: '李娜', dept: '研发一部', product: 'Orion 模组', type: 'ICT', prio: 'mid', est: 180, note: '' },
      { id: 'T-1003', shift: 'day',   machine: 'M-02', start: 60,  end: 240, status: 'done',
        pe: '张涛', dept: '研发二部', product: 'Vega 子板', type: 'ICT', prio: 'low', est: 180, note: '' },
      { id: 'T-1004', shift: 'day',   machine: 'M-02', start: 270, end: 510, status: 'running',
        pe: '陈明', dept: '研发二部', product: 'Apollo 主板', type: 'ICT', prio: 'high', est: 240, note: '' },
      { id: 'T-1005', shift: 'day',   machine: 'M-03', start: 30,  end: 360, status: 'done',
        pe: '刘洋', dept: '研发一部', product: 'Nova 整机', type: 'FCT', prio: 'mid', est: 330, note: '' },
      { id: 'T-1006', shift: 'day',   machine: 'M-03', start: 360, end: 600, status: 'running',
        pe: '王伟', dept: '研发一部', product: 'Orion 模组', type: 'FCT', prio: 'high', est: 240, note: '' },
      { id: 'T-1007', shift: 'day',   machine: 'M-05', start: 420, end: 600, status: 'scheduled',
        pe: '赵敏', dept: '研发三部', product: 'Pulsar 射频板', type: 'RF', prio: 'mid', est: 180, source: 'self', checkedIn: false, note: '' },
      { id: 'T-1008', shift: 'day',   machine: 'M-01', start: 480, end: 600, status: 'scheduled',
        pe: '王伟', dept: '研发一部', product: 'Apollo 主板', type: 'ICT', prio: 'mid', est: 120, source: 'self', checkedIn: false, note: '白班自助预约 · 待签到（16:00）' },

      // ---------- 夜班 night shift（PE 白班提交，Lab 工程师夜间执行）----------
      { id: 'T-2001', shift: 'night', machine: 'M-01', start: 720,  end: 900,  status: 'scheduled',
        pe: '李娜', dept: '研发一部', product: 'Orion 模组', type: 'ICT', prio: 'high', est: 180, note: '' },
      { id: 'T-2002', shift: 'night', machine: 'M-01', start: 930,  end: 1110, status: 'scheduled',
        pe: '王伟', dept: '研发一部', product: 'Apollo 主板', type: 'ICT', prio: 'mid', est: 180, note: '' },
      { id: 'T-2003', shift: 'night', machine: 'M-02', start: 750,  end: 1020, status: 'scheduled',
        pe: '陈明', dept: '研发二部', product: 'Vega 子板', type: 'ICT', prio: 'mid', est: 270, note: '' },
      { id: 'T-2004', shift: 'night', machine: 'M-03', start: 780,  end: 1200, status: 'scheduled',
        pe: '刘洋', dept: '研发一部', product: 'Nova 整机', type: 'FCT', prio: 'high', est: 420, note: '夜间长时间老化+功能复测' },
      { id: 'T-2005', shift: 'night', machine: 'M-05', start: 720,  end: 1140, status: 'scheduled',
        pe: '赵敏', dept: '研发三部', product: 'Pulsar 射频板', type: 'RF', prio: 'low', est: 420, note: '' },

      // ---------- 待排程 pending（智能算法待规划 / 机台不可用导致挂起）----------
      { id: 'T-2006', shift: 'night', machine: null, start: null, end: null, status: 'pending',
        pe: '张涛', dept: '研发二部', product: 'Quasar 电源板', type: '老化', prio: 'mid', est: 360, note: 'BURN-01 故障，等待机台恢复或改派' },
      { id: 'T-2007', shift: 'day',   machine: null, start: null, end: null, status: 'pending',
        pe: '周琳', dept: '研发三部', product: 'Comet 传感模组', type: 'FCT', prio: 'high', est: 150, note: '今日新提交，待算法插入白班空档' },

      // ---------- 明日规划 day +1（算法已提前排好）----------
      { id: 'T-1101', day: 1, shift: 'day',   machine: 'M-01', start: 60,  end: 210,  status: 'scheduled',
        pe: '王伟', dept: '研发一部', product: 'Apollo 主板', type: 'ICT', prio: 'mid', est: 150, note: '明日首件复测' },
      { id: 'T-1102', day: 1, shift: 'day',   machine: 'M-02', start: 30,  end: 240,  status: 'scheduled',
        pe: '李娜', dept: '研发一部', product: 'Orion 模组', type: 'ICT', prio: 'high', est: 210, note: '' },
      { id: 'T-1103', day: 1, shift: 'day',   machine: 'M-03', start: 120, end: 420,  status: 'scheduled',
        pe: '刘洋', dept: '研发一部', product: 'Nova 整机', type: 'FCT', prio: 'mid', est: 300, note: '' },
      { id: 'T-1104', day: 1, shift: 'day',   machine: 'M-05', start: 300, end: 480,  status: 'scheduled',
        pe: '赵敏', dept: '研发三部', product: 'Pulsar 射频板', type: 'RF', prio: 'low', est: 180, note: '' },
      { id: 'T-2101', day: 1, shift: 'night', machine: 'M-01', start: 720, end: 960,  status: 'scheduled',
        pe: '王伟', dept: '研发一部', product: 'Apollo 主板', type: 'ICT', prio: 'high', est: 240, note: '夜间老化 + 功能复测' },
      { id: 'T-2102', day: 1, shift: 'night', machine: 'M-03', start: 780, end: 1140, status: 'scheduled',
        pe: '陈明', dept: '研发二部', product: 'Vega 子板', type: 'ICT', prio: 'mid', est: 360, note: '' },
    ],
  };

  // ---- persistence ----
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    const s = clone(SEED);
    save(s);
    return s;
  }
  function save(s) {
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {}
  }
  // next sequential id for an editable sheet row, e.g. rowId('BR', rules) → 'BR-5'
  function rowId(prefix, arr) {
    let n = 0;
    arr.forEach(r => { const m = /(\d+)$/.exec(r.id || ''); if (m) n = Math.max(n, +m[1]); });
    return prefix + '-' + (n + 1);
  }

  let state = load();

  // ---- helpers ----
  function minToClock(offset) {
    if (offset == null) return '—';
    let total = 480 + offset;
    const h = Math.floor(total / 60) % 24;
    const m = total % 60;
    return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
  }
  function fmtDur(min) {
    if (min == null) return '—';
    const h = Math.floor(min / 60), m = min % 60;
    return (h ? h + 'h' : '') + (m ? m + 'min' : (h ? '' : '0min'));
  }
  // date label for a day-offset relative to the simulated "today" (state.today)
  function dateLabel(offset) {
    const base = new Date(state.today + 'T00:00:00');
    const d = new Date(base.getTime() + offset * 86400000);
    const wd = ['周日','周一','周二','周三','周四','周五','周六'][d.getDay()];
    const text = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    return { text, wd, isToday: offset === 0 };
  }
  function dayName(offset) {
    return offset === 0 ? '今天' : offset === 1 ? '明天' : offset === -1 ? '昨天'
         : (offset > 0 ? '+' + offset + '天' : offset + '天');
  }

  const STATUS_META = {
    pending:   { label: '待排程',  cls: 'neutral' },
    scheduled: { label: '已排程',  cls: 'info' },
    running:   { label: '测试中',  cls: 'running' },
    done:      { label: '已完成',  cls: 'ok' },
    hold:      { label: '已挂起',  cls: 'warn' },
    fail:      { label: '测试异常', cls: 'danger' },
  };
  const MACHINE_STATUS = {
    idle:        { label: '空闲',   cls: 'ok',      schedulable: true  },
    running:     { label: '运行中', cls: 'running', schedulable: true  },
    maintenance: { label: '保养中', cls: 'warn',    schedulable: false },
    fault:       { label: '故障',   cls: 'danger',  schedulable: false },
  };
  const PRIO_META = {
    high: { label: '高', cls: 'p-high', rank: 0 },
    mid:  { label: '中', cls: 'p-mid',  rank: 1 },
    low:  { label: '低', cls: 'p-low',  rank: 2 },
  };

  const Store = {
    get state() { return state; },
    get machines() { return state.machines; },
    get tasks() { return state.tasks; },
    nowMin: () => state.nowMin,
    today: () => state.today,

    machine(id) { return state.machines.find(m => m.id === id); },
    task(id) { return state.tasks.find(t => t.id === id); },
    tasksByShift(shift) { return state.tasks.filter(t => t.shift === shift); },
    schedulableMachines() { return state.machines.filter(m => MACHINE_STATUS[m.status].schedulable); },

    setMachineStatus(id, status, note) {
      const m = this.machine(id);
      if (!m) return;
      m.status = status;
      if (note != null) m.note = note;
      save(state);
    },
    setTaskStatus(id, status, note) {
      const t = this.task(id);
      if (!t) return;
      t.status = status;
      if (note != null) t.note = note;
      save(state);
    },
    setTaskMachine(id, machine) {
      const t = this.task(id);
      if (!t) return;
      t.machine = machine;
      t.moved = true;
      save(state);
    },
    setTaskPrio(id, prio) {
      const t = this.task(id);
      if (!t) return;
      t.prio = prio;
      save(state);
    },
    addTask(t) {
      state.tasks.push(t);
      save(state);
    },
    updateTask(id, fields) {
      const t = this.task(id);
      if (!t) return;
      Object.assign(t, fields);
      save(state);
    },
    removeTask(id) {
      const i = state.tasks.findIndex(t => t.id === id);
      if (i >= 0) state.tasks.splice(i, 1);
      save(state);
    },
    // 智能排测算法（原型）：清空原占位，按班次/当天找最早空档重新分配。
    // 工程师无法指定机台或时间 —— 每次编辑都会重排，从机制上杜绝提前占位。
    autoSchedule(id) {
      const t = this.task(id);
      if (!t) return null;
      const day = t.day || 0;
      const [lo, hi] = this.SHIFT_RANGE[t.shift];
      // release current placement first
      t.machine = null; t.start = null; t.end = null;
      let best = null;
      for (const m of this.schedulableMachines()) {
        const occ = state.tasks.filter(x => x.id !== id && x.machine === m.id && x.start != null
                      && (x.day || 0) === day && x.shift === t.shift).sort((a, b) => a.start - b.start);
        let cursor = lo;
        if (day === 0 && t.shift === 'day') cursor = Math.max(cursor, state.nowMin); // 不排到过去
        for (const o of occ) { if (o.start - cursor >= t.est) break; cursor = Math.max(cursor, o.end); }
        if (cursor + t.est <= hi && (!best || cursor < best.start)) best = { machine: m.id, start: cursor };
      }
      if (best) { t.machine = best.machine; t.start = best.start; t.end = best.start + t.est; t.status = 'scheduled'; }
      else { t.status = 'pending'; }
      save(state);
      return best;
    },
    useManagerAdjust(taskId) {
      state.meta.managerAdjustUsed = true;
      state.meta.managerAdjustTask = taskId;
      save(state);
    },

    // ---- departments / quota (白班借机配额，仅白天计) ----
    get departments() { return state.departments; },
    department(name) { return state.departments.find(d => d.name === name); },
    quotaUsedMin(deptName, day) {
      day = day || 0;
      return state.tasks
        .filter(t => t.dept === deptName && t.shift === 'day' && (t.day || 0) === day && t.machine && t.start != null)
        .reduce((a, t) => a + (t.end - t.start), 0);
    },
    setDeptQuota(name, fields) {
      const d = this.department(name);
      if (d) { Object.assign(d, fields); save(state); }
    },

    // ---- 借机规则 / 机台零部件说明（Lab 工程师维护，像表格一样增删改）----
    get borrowRules() { return state.borrowRules; },
    addBorrowRule(row) { state.borrowRules.push(Object.assign({ id: rowId('BR', state.borrowRules) }, row)); save(state); },
    updateBorrowRule(id, fields) { const r = state.borrowRules.find(x => x.id === id); if (r) { Object.assign(r, fields); save(state); } },
    removeBorrowRule(id) { const i = state.borrowRules.findIndex(x => x.id === id); if (i >= 0) { state.borrowRules.splice(i, 1); save(state); } },
    // 借机规则 — 按 (机台, 星期) 单元格读写；depts 为部门集合（可多部门共享）
    borrowRuleFor(machine, weekday) { return state.borrowRules.find(r => r.machine === machine && r.weekday === weekday); },
    toggleBorrowDept(machine, weekday, dept) {
      if (!dept) return;
      let r = this.borrowRuleFor(machine, weekday);
      if (!r) { state.borrowRules.push({ id: rowId('BR', state.borrowRules), machine, weekday, depts: [dept], note: '' }); save(state); return; }
      const i = r.depts.indexOf(dept);
      if (i >= 0) { r.depts.splice(i, 1); if (r.depts.length === 0) state.borrowRules.splice(state.borrowRules.indexOf(r), 1); }
      else { r.depts.push(dept); }
      save(state);
    },
    clearBorrow(machine, weekday) {
      const r = this.borrowRuleFor(machine, weekday);
      if (r) { state.borrowRules.splice(state.borrowRules.indexOf(r), 1); save(state); }
    },
    setBorrowNote(machine, weekday, note) {
      const r = this.borrowRuleFor(machine, weekday);
      if (r) { r.note = note; save(state); }
    },
    get machineParts() { return state.machineParts; },
    addMachinePart(row) { state.machineParts.push(Object.assign({ id: rowId('MP', state.machineParts) }, row)); save(state); },
    updateMachinePart(id, fields) { const r = state.machineParts.find(x => x.id === id); if (r) { Object.assign(r, fields); save(state); } },
    removeMachinePart(id) { const i = state.machineParts.findIndex(x => x.id === id); if (i >= 0) { state.machineParts.splice(i, 1); save(state); } },

    // ---- 节假日日历（已与中国大陆法定节假日同步，自动更新，无需人工维护）----
    dateKind(dateText) {
      if (CN_MAKEUP_WORKDAYS.includes(dateText)) return 'makeup';   // 调休上班
      if (CN_HOLIDAYS.includes(dateText)) return 'holiday';         // 法定节假日
      const dow = new Date(dateText + 'T00:00:00').getDay();
      return (dow === 0 || dow === 6) ? 'weekend' : 'workday';
    },
    isHoliday(dateText) { const k = this.dateKind(dateText); return k === 'holiday' || k === 'weekend'; },
    // 某天某时段的执行模式：工作日白班=自助预约；夜间/周末/节假日=算法+Lab 代测
    mode(dayOffset, shift) {
      const kind = this.dateKind(dateLabel(dayOffset).text);
      if (kind === 'holiday') return { kind: 'algo', exec: 'lab', label: '节假日·算法代测' };
      if (kind === 'weekend') return { kind: 'algo', exec: 'lab', label: '周末·算法代测' };
      if (shift === 'day') return { kind: 'self', exec: 'pe', label: '工作日白班·自助预约' };
      return { kind: 'algo', exec: 'lab', label: '工作日夜班·算法代测' };
    },

    // ---- daytime reservation check-in ----
    checkIn(id) { const t = this.task(id); if (t) { t.checkedIn = true; t.status = 'running'; save(state); } },
    checkOut(id, note) { const t = this.task(id); if (t) { t.status = 'done'; if (note != null) t.note = note; save(state); } },

    // ---- role layer (role is now a filter, not a nav axis) ----
    ROLES: {
      pe:      { key: 'pe',      label: 'PE 工程师',  who: '王伟', home: 'workspace.html' },
      manager: { key: 'manager', label: 'PE 管理者',  who: '主管', home: 'workspace.html' },
      lab:     { key: 'lab',     label: 'Lab 工程师', who: '黄工', home: 'workspace.html' },
    },
    get currentRole() { return localStorage.getItem('itest-role') || 'pe'; },
    setRole(r) { try { localStorage.setItem('itest-role', r); } catch (e) {} },
    role() { return this.ROLES[this.currentRole] || this.ROLES.pe; },

    persist() { save(state); },
    reset() { localStorage.removeItem(KEY); state = load(); },

    minToClock, fmtDur, dateLabel, dayName,
    STATUS_META, MACHINE_STATUS, PRIO_META,
    SHIFT_RANGE: { day: [0, 720], night: [720, 1440] },
    CURRENT_PE: '王伟',   // the logged-in PE engineer (for the「我的」filter)
  };

  global.Store = Store;
})(window);
