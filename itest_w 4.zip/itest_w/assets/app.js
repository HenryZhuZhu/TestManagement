/* ============================================================
   iTest 智能排测系统 — shared UI utilities
   Header / footer / theme / toast / modal / gantt renderer
   ============================================================ */
(function (global) {
  const S = global.Store;

  // ---------- icons ----------
  const ICON = {
    logo: '<svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><rect x="7" y="11" width="3" height="7"/><rect x="13" y="6" width="3" height="12"/></svg>',
    sun:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="4.5"/><path d="M12 1.5v2M12 20.5v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1.5 12h2M20.5 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/></svg>',
    reset:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>',
    check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
    close:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    arrow:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    up:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M6 11l6-6 6 6"/></svg>',
    down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M6 13l6 6 6-6"/></svg>',
    info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.5"/><path d="M12 16v-5M12 8h.01"/></svg>',
    chevL:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>',
    chevR:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>',
  };

  // 一级导航 = 业务域（角色降为过滤器，见 role switcher）
  const NAV = [
    { href: 'workspace.html', label: '工作台' },
    { href: 'schedule.html',  label: '排测中心' },
    { href: 'machines.html',  label: '机台中心' },
    { href: 'analytics.html', label: '运营分析' },
    { href: 'config.html',    label: '系统配置' },
  ];
  // 旧角色页 → 归入对应业务域（用于高亮一级导航）
  const NAV_ALIAS = {
    'index.html': 'workspace.html',
  };

  // ---------- header / footer ----------
  // mountChrome(activePageOrNull) — role is a global filter shown as a switcher.
  function mountChrome(active) {
    const page = active || location.pathname.split('/').pop() || 'workspace.html';
    const activeTop = NAV_ALIAS[page] || page;
    const links = NAV.map(n =>
      `<a href="${n.href}" class="${activeTop === n.href ? 'active' : ''}">${n.label}</a>`
    ).join('');
    const role = S.role();
    const roleOpts = Object.values(S.ROLES).map(r =>
      `<option value="${r.key}" ${r.key === role.key ? 'selected' : ''}>${r.label} · ${r.who}</option>`).join('');
    const header = `
      <header class="site-header">
        <div class="inner">
          <a class="brand" href="workspace.html">
            <span class="logo grad-6">${ICON.logo}</span> iTest <span class="muted" style="font-weight:500">智能排测</span>
          </a>
          <nav class="nav-links">${links}</nav>
          <div class="header-right">
            <span class="role-switch" title="切换当前角色（角色=权限与默认视图的过滤器）">
              <span class="dot"></span>
              <select id="role-select">${roleOpts}</select>
            </span>
            <button class="icon-btn" id="reset-btn" title="重置演示数据">${ICON.reset}</button>
            <button class="icon-btn" id="theme-toggle" title="切换主题">${ICON.sun}</button>
          </div>
        </div>
      </header>`;
    document.body.insertAdjacentHTML('afterbegin', header);

    document.getElementById('role-select').addEventListener('change', (e) => {
      S.setRole(e.target.value);
      location.reload();
    });
    document.getElementById('reset-btn').addEventListener('click', () => {
      if (confirm('重置全部演示数据到初始状态？')) { S.reset(); location.reload(); }
    });
    initTheme();
  }

  function mountFooter() {
    const footer = `
      <footer class="site-footer">
        <div class="cols">
          <div class="col brand">
            <div class="brand"><span class="logo grad-6" style="width:24px;height:24px;border-radius:7px">${ICON.logo}</span> iTest 智能排测</div>
            <p class="tagline">面向工程实验机台的智能排测平台 —— PE 提交申请，算法统一规划白班 / 夜班测试，机台资源透明、用尽其用。</p>
          </div>
          <ul>
            <li><a href="workspace.html">工作台</a></li>
            <li><a href="schedule.html">排测中心</a></li>
            <li><a href="apply.html">申请与预约</a></li>
            <li><a href="machines.html">机台中心</a></li>
            <li><a href="analytics.html">运营分析</a></li>
            <li><a href="config.html">系统配置</a></li>
          </ul>
        </div>
        <div class="bottom mono">iTest Smart Scheduling · 原型演示 · 数据保存在本地浏览器</div>
      </footer>`;
    document.body.insertAdjacentHTML('beforeend', footer);
  }

  // ---------- theme ----------
  function initTheme() {
    const root = document.documentElement;
    const stored = localStorage.getItem('itest-theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (stored === 'dark' || (!stored && prefersDark)) root.classList.add('dark');
    document.getElementById('theme-toggle')?.addEventListener('click', () => {
      root.classList.toggle('dark');
      localStorage.setItem('itest-theme', root.classList.contains('dark') ? 'dark' : 'light');
    });
  }

  // ---------- toast ----------
  let toastWrap;
  function toast(msg, kind) {
    if (!toastWrap) {
      toastWrap = document.createElement('div');
      toastWrap.className = 'toast-wrap';
      document.body.appendChild(toastWrap);
    }
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = `<span class="ti" style="color:${kind === 'warn' ? 'var(--warn)' : 'var(--ok)'}">${ICON.check}</span>${msg}`;
    toastWrap.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; }, 2400);
    setTimeout(() => el.remove(), 2750);
  }

  // ---------- modal ----------
  function modal({ title, sub, body, foot }) {
    const back = document.createElement('div');
    back.className = 'modal-backdrop';
    back.innerHTML = `
      <div class="modal" role="dialog">
        <div class="modal-head">
          <div><h3>${title}</h3>${sub ? `<div class="sub">${sub}</div>` : ''}</div>
          <button class="icon-btn" data-close>${ICON.close}</button>
        </div>
        <div class="modal-body">${body}</div>
        ${foot ? `<div class="modal-foot">${foot}</div>` : ''}
      </div>`;
    document.body.appendChild(back);
    const close = () => { document.removeEventListener('keydown', onKey); back.remove(); };
    const onKey = e => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey);
    back.addEventListener('click', e => { if (e.target === back || e.target.closest('[data-close]')) close(); });
    // move focus into the dialog (first field, else the dialog itself)
    const dlg = back.querySelector('.modal');
    const first = back.querySelector('.modal-body input, .modal-body select, .modal-body textarea');
    if (first) first.focus();
    else if (dlg) { dlg.setAttribute('tabindex', '-1'); dlg.focus(); }
    return { el: back, close };
  }

  // ---------- gantt ----------
  // opts: { shift:'day'|'night'|'all', day:0, pe:null, mount:el, onBar:fn(task) }
  function renderGantt(mount, opts) {
    opts = opts || {};
    const shift = opts.shift || 'all';
    const day = opts.day || 0;
    const pe = opts.pe || null;
    const SPAN = 1440;             // minutes across timeline
    const tasks = S.tasks.filter(t => t.machine && t.start != null &&
      (t.day || 0) === day &&
      (shift === 'all' || t.shift === shift) &&
      (!pe || t.pe === pe));

    // axis ticks every 2h
    let axis = '';
    for (let off = 0; off <= SPAN; off += 120) {
      const left = (off / SPAN) * 100;
      if (off < SPAN) axis += `<div class="tick" style="left:${left}%">${S.minToClock(off)}</div>`;
    }
    // shift bands
    axis += `<div class="shift-band day" style="left:${(0/SPAN)*100}%;width:${(720/SPAN)*100}%">白班 08–20</div>`;
    axis += `<div class="shift-band night" style="left:${(720/SPAN)*100}%;width:${(720/SPAN)*100}%">夜班 20–08</div>`;

    // gridlines for every track
    let gridlines = '';
    for (let off = 120; off < SPAN; off += 120) {
      gridlines += `<div class="gridline" style="left:${(off/SPAN)*100}%"></div>`;
    }
    const nightWash = `<div class="nightwash" style="left:${(720/SPAN)*100}%;width:${(720/SPAN)*100}%"></div>`;

    const now = S.nowMin();
    const nowLine = `<div class="gantt-now" style="left:${(now/SPAN)*100}%"></div>`;

    const rows = S.machines.map(m => {
      const ms = S.MACHINE_STATUS[m.status];
      const disabled = !ms.schedulable;
      const bars = tasks.filter(t => t.machine === m.id).map(t => {
        const left = (t.start / SPAN) * 100;
        const width = ((t.end - t.start) / SPAN) * 100;
        const cls = t.status === 'running' ? 'b-running'
                  : t.status === 'done'    ? 'b-done'
                  : t.status === 'hold'    ? 'b-hold'
                  : t.shift === 'night'    ? 'b-night' : 'b-day';
        const pm = S.PRIO_META[t.prio];
        const own = opts.meHighlight && t.pe === opts.meHighlight;
        return `<div class="gbar ${cls} ${t.moved ? 'moved' : ''} ${own ? 'own' : ''}" style="left:${left}%;width:${width}%"
                  data-task="${t.id}" title="${t.id} · ${t.product}${own ? ' · 双击编辑' : ''}">
                  <div class="gt">${t.product}</div>
                  <div class="gm">${t.id} · ${t.pe} · ${S.minToClock(t.start)}-${S.minToClock(t.end)} · 优先级${pm.label}</div>
                </div>`;
      }).join('');
      return `
        <div class="gantt-row ${disabled ? 'disabled' : ''}">
          <div class="rowlabel">
            <span class="mname"><span class="sdot" style="background:var(--${ms.cls === 'neutral' ? 'muted' : ms.cls})"></span>${m.name}</span>
            <span class="mmeta">${m.type} · ${ms.label}</span>
          </div>
          <div class="gantt-track">
            ${shift === 'all' ? nightWash : ''}
            ${gridlines}
            ${(day === 0 && (shift === 'all' || (now >= S.SHIFT_RANGE[shift][0] && now <= S.SHIFT_RANGE[shift][1]))) ? nowLine : ''}
            ${bars}
          </div>
        </div>`;
    }).join('');

    mount.innerHTML = `
      <div class="gantt">
        <div class="gantt-scroll">
          <div class="gantt-inner">
            <div class="gantt-headrow">
              <div class="corner">机台 / 时间轴</div>
              <div class="gantt-axis">${axis}</div>
            </div>
            ${rows}
          </div>
        </div>
      </div>`;

    if (opts.onBar || opts.onBarDouble) {
      mount.querySelectorAll('.gbar').forEach(b => {
        let timer = null;
        b.addEventListener('click', () => {
          if (opts.onBarDouble) {           // delay single-click so a dblclick can cancel it
            if (timer) return;
            timer = setTimeout(() => { timer = null; opts.onBar && opts.onBar(S.task(b.dataset.task)); }, 230);
          } else {
            opts.onBar(S.task(b.dataset.task));
          }
        });
        if (opts.onBarDouble) {
          b.addEventListener('dblclick', () => {
            if (timer) { clearTimeout(timer); timer = null; }
            opts.onBarDouble(S.task(b.dataset.task));
          });
        }
      });
    }
  }

  function taskDetailHTML(t) {
    const sm = S.STATUS_META[t.status], pm = S.PRIO_META[t.prio];
    const m = t.machine ? S.machine(t.machine) : null;
    // build rows conditionally so legacy seed tasks render as before, new rich tasks show extra fields
    const rows = [
      ['排测单号', `<span class="mono">${t.id}</span>`],
      ['产品 / 型号', t.product],
      t.serial && ['产品编号', t.serial],
      t.batch && ['产品批号', t.batch],
      t.purpose && ['测试目的', t.purpose],
      ['测试板 / 类型', t.type],
      (t.size || t.qty) && ['产品大小 / 数量', `${t.size || '—'} · ${t.qty != null ? t.qty + ' 件' : '—'}`],
      t.program && ['测试主程序', t.program],
      t.path && ['测试路径', t.path],
      t.funcKey && ['Function Key', t.funcKey],
      t.splitBin && ['是否分 BIN', t.splitBin],
      ['申请人', `${t.pe} · ${t.dept}`],
      t.lab && ['实验室', t.lab],
      ['班次', t.shift === 'night' ? '夜班 20:00–08:00' : '白班 08:00–20:00'],
      ['机台', m ? m.name + ' · ' + m.type : '待算法分配'],
      ['时间窗', t.start != null ? S.minToClock(t.start) + ' – ' + S.minToClock(t.end) : '待规划'],
      ['预估时长', S.fmtDur(t.est)],
      (t.temps && t.temps.length) && ['测试温度', t.temps.join('、')],
      ['优先级', `<span class="prio ${pm.cls}">${pm.label}</span>`],
      ['状态', `<span class="badge ${sm.cls}"><span class="dot"></span>${sm.label}</span>`],
      ['备注', t.note || '—'],
      (t.attachments && t.attachments.length) && ['附件', t.attachments.map(a => a.name).join('、')],
    ].filter(Boolean);
    return `<dl class="kv">${rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>`;
  }

  // persistent floating action button
  function mountFab(href, label) {
    const a = document.createElement('a');
    a.className = 'fab';
    a.href = href;
    a.innerHTML = ICON.plus + '<span>' + label + '</span>';
    document.body.appendChild(a);
  }

  // reveal-on-scroll
  function initReveal() {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in-view'); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    document.querySelectorAll('.reveal').forEach(el => io.observe(el));
  }

  global.App = { mountChrome, mountFooter, mountFab, toast, modal, renderGantt, taskDetailHTML, initReveal, ICON };
})(window);
