(function () {
  let activeMode = 'self';
  const currentUser = Store.CURRENT_PE;
  const currentDept = (Store.tasks.find(task => task.pe === currentUser) || {}).dept || '研发一部';
  const selfFields = document.getElementById('self-fields');
  const algoFields = document.getElementById('algo-fields');

  document.getElementById('excluded-machines').innerHTML = Store.schedulableMachines().map(machine =>
    `<option value="${machine.id}">${machine.name} · ${machine.type} · ${machine.lab}</option>`
  ).join('');

  function normalizeTemperature(value) {
    const normalized = value.trim().replace(/°C$/i, '℃');
    if (!normalized) return '';
    return /℃$/.test(normalized) ? normalized : `${normalized}℃`;
  }

  function addTemperatureRow(value = '') {
    const row = document.createElement('div');
    row.className = 'temperature-row';
    row.innerHTML = `<input name="temperatures" type="text" value="${value}" placeholder="手动填写温度，如 25℃"><button class="btn small" type="button" data-remove-temperature>删除</button>`;
    row.querySelector('[data-remove-temperature]').addEventListener('click', () => {
      row.remove();
      if (!document.querySelector('#night-temperature-rows .temperature-row')) addTemperatureRow();
    });
    document.getElementById('night-temperature-rows').appendChild(row);
    if (activeMode === 'self') row.querySelector('input').disabled = true;
  }

  function setMode(nextMode) {
    activeMode = nextMode;
    const isSelf = activeMode === 'self';
    document.querySelectorAll('.mode-card').forEach(card => card.classList.toggle('active', card.dataset.mode === activeMode));
    selfFields.classList.toggle('hidden', !isSelf);
    selfFields.querySelectorAll('input,select,textarea').forEach(field => { field.disabled = !isSelf; });
    algoFields.classList.toggle('hidden', isSelf);
    algoFields.querySelectorAll('input,select,textarea').forEach(field => { field.disabled = isSelf; });
    document.querySelectorAll('.algo-only').forEach(section => section.classList.toggle('hidden', isSelf));
    document.querySelectorAll('.algo-only input,.algo-only select,.algo-only textarea').forEach(field => { field.disabled = isSelf; });
    document.getElementById('quota').classList.toggle('hidden', !isSelf);
    document.getElementById('mode-chip').textContent = isSelf ? '白班自助预约' : '算法统一排程';
    document.getElementById('submit').textContent = isSelf ? '提交预约' : '提交需求 · 交给算法';
  }

  document.querySelectorAll('.mode-card').forEach(card => {
    card.onclick = () => setMode(card.dataset.mode);
  });
  setMode('self');

  document.getElementById('form').onsubmit = event => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const estimatedDuration = Number(formData.get('est'));
    const id = (activeMode === 'self' ? 'R-' : 'T-') + Math.floor(6000 + Math.random() * 3000);
    const baseTask = {
      id,
      pe: currentUser,
      dept: currentDept,
      product: formData.get('model'),
      type: formData.get('type'),
      est: estimatedDuration,
      purpose: formData.get('purpose'),
      status: 'scheduled'
    };

    if (activeMode === 'self') {
      const preferredMachine = formData.get('machine');
      const excludedMachines = formData.getAll('excludedMachines');
      if (excludedMachines.includes(preferredMachine)) {
        V2App.toast('意向机台不能同时设为排他机台', 'warn');
        return;
      }
      const start = Number(formData.get('start'));
      Store.addTask({
        ...baseTask,
        day: Number(formData.get('day')),
        shift: 'day',
        machine: preferredMachine,
        preferredMachine,
        excludedMachines,
        start,
        end: start + estimatedDuration,
        prio: 'mid',
        source: 'self',
        checkedIn: false
      });
    } else {
      const temperatures = [...new Set(formData.getAll('temperatures').map(normalizeTemperature).filter(Boolean))];
      if (temperatures.length === 0) {
        V2App.toast('请至少添加一个测试温度', 'warn');
        return;
      }
      Store.addTask({
        ...baseTask,
        serial: formData.get('serial'),
        batch: formData.get('batch'),
        qty: Number(formData.get('qty')),
        program: formData.get('program'),
        temps: temperatures,
        temperature: temperatures.join('、'),
        note: formData.get('note') || '',
        day: Number(formData.get('algoDay')),
        shift: 'night',
        machine: null,
        start: null,
        end: null,
        status: 'pending',
        prio: formData.get('prio')
      });
      Store.autoSchedule(id);
    }
    V2App.toast('工单已提交，正在返回排测中心');
    setTimeout(() => { location.href = 'index.html?focus=' + id; }, 650);
  };

  addTemperatureRow();
  document.getElementById('night-temperature-add').addEventListener('click', () => addTemperatureRow());
})();