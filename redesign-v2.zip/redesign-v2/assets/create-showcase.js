(function () {
  const variant = Number(document.body.dataset.createVariant || 1);
  const isOfficial = document.body.dataset.createOfficial === 'true';
  const designConcept = document.body.dataset.designConcept || '';
  const isDesignPreview = Boolean(designConcept);
  const isBusinessPreview = designConcept.startsWith('business-');
  const names = ['顺序表单', '导航侧栏', '双栏工作台', '紧凑清单', '分区画布'];
  const currentUser = Store.CURRENT_PE;
  const currentDept = (Store.tasks.find(task => task.pe === currentUser) || {}).dept || '研发一部';
  let activeMode = 'self';

  const variantNav = isOfficial ? '' : isBusinessPreview ? `<nav class="business-preview-nav" aria-label="业务表单样式方案">
    <a class="${designConcept === 'business-grid' ? 'active' : ''}" href="create-business-1.html"><span>01</span>紧凑三列</a>
    <a class="${designConcept === 'business-rows' ? 'active' : ''}" href="create-business-2.html"><span>02</span>横向分区</a>
  </nav>` : isDesignPreview ? `<nav class="design-preview-nav" aria-label="Design.md 样式方案">
    <a class="${designConcept === 'soft' ? 'active' : ''}" href="create-design-1.html"><span>01</span>柔和顺序</a>
    <a class="${designConcept === 'focus' ? 'active' : ''}" href="create-design-2.html"><span>02</span>聚焦侧栏</a>
  </nav>` : `<nav class="variant-nav" aria-label="样式方案">
    ${names.map((name, index) => `<a class="${variant === index + 1 ? 'active' : ''}" href="create-style-${index + 1}.html"><span>0${index + 1}</span>${name}</a>`).join('')}
  </nav>`;

  const pageHead = `<div class="prototype-head">
    <div>${isOfficial ? '<h1>新建工单</h1><p>选择执行方式后，按顺序填写工单信息。</p>' : isBusinessPreview ? `<h1>新建工单</h1><p>${designConcept === 'business-grid' ? '紧凑填写，关键信息一屏完成。' : '按业务分区横向填写，减少视线跳转。'}</p>` : isDesignPreview ? `<div class="prototype-kicker">DESIGN.MD · ${designConcept === 'soft' ? 'SOFT FLOW' : 'FOCUS RAIL'}</div><h1>新建工单</h1><p>${designConcept === 'soft' ? '沿着清晰顺序，完成一次测试申请。' : '测试信息与排程分区呈现，保持注意力集中。'}</p>` : `<div class="prototype-kicker">新建工单 · 方案 0${variant}</div><h1>新建工单</h1>`}</div>
    <a class="btn" href="index.html">返回排测中心</a>
  </div>`;

  const modeSwitch = `<div class="mode-switch" role="tablist" aria-label="执行方式">
    <button type="button" class="active" data-mode="self"><strong>白班自测</strong><span>工作日 08:00–20:00</span></button>
    <button type="button" data-mode="algo"><strong>夜班 / 休息日</strong><span>Lab 代测 · 算法排程</span></button>
  </div>`;

  const identity = `<div class="identity-strip">
    <div data-field-label="申请人"><span>申请人</span><strong id="pe"></strong></div>
    <div data-field-label="部门"><span>部门</span><strong id="dept"></strong></div>
  </div>`;

  const objectSection = `<section class="form-block" data-step="01">
    <div class="block-head"><div><span>01</span><h2>测试对象</h2></div><small>基础信息</small></div>
    <div class="field-grid">
      <div class="field" data-field-label="产品"><label>产品 <span class="req">*</span></label><select name="model" required><option value="">请选择产品</option><option>Apollo-V1</option><option>Orion</option><option>Nova</option><option>Pulsar</option><option>Quasar</option></select></div>
      <div class="field" data-field-label="测试类型"><label>测试类型 <span class="req">*</span></label><select name="type" required><option value="">请选择类型</option><option>ICT</option><option>FCT</option><option>RF</option><option>老化</option></select></div>
      <div class="field wide" data-field-label="测试目的"><label>测试目的 <span class="req">*</span></label><input name="purpose" required placeholder="例如：DVT 阶段功能验证"></div>
      <div class="field" data-mode-only="algo"><label>产品编号 <span class="req">*</span></label><input name="serial" required placeholder="例如：SN-000123"></div>
      <div class="field" data-mode-only="algo"><label>产品批号</label><input name="batch" placeholder="例如：LOT-260821"></div>
      <div class="field" data-mode-only="algo"><label>产品数量 <span class="req">*</span></label><input name="qty" type="number" min="1" value="1" required></div>
    </div>
  </section>`;

  const requirementSection = `<section class="form-block" data-mode-only="algo" data-step="02">
    <div class="block-head"><div><span>02</span><h2>测试要求</h2></div><small>Lab 执行信息</small></div>
    <div class="field-grid">
      <div class="field"><label>实验室 <span class="req">*</span></label><select name="lab" required><option value="">请选择实验室</option><option>A区</option><option>B区</option></select></div>
      <div class="field"><label>测试主程序 <span class="req">*</span></label><input name="program" required placeholder="例如：Apollo_FCT_v3.2"></div>
      <div class="field wide temperature-field"><label>测试温度 <span class="req">*</span><span class="label-note">同一主程序可填写多个温度</span></label><div class="temperature-rows" id="temperature-rows"></div><button class="btn small temperature-add" type="button" id="temperature-add">＋ 新增温度</button></div>
      <div class="field"><label>是否分 BIN</label><select name="bin"><option>不需要</option><option>需要</option></select></div>
    </div>
  </section>`;

  const scheduleSection = `<section class="form-block schedule-block" data-step="03">
    <div class="block-head"><div><span data-schedule-step>02</span><h2>排程信息</h2></div><small id="mode-chip">白班自助预约</small></div>
    <div class="notice warn" id="quota" data-mode-only="self"></div>
    <div class="field-grid schedule-grid" data-mode-only="self">
      <div class="field" data-field-label="预约日期"><label>预约日期 <span class="req">*</span></label><select name="day" id="day"></select></div>
      <div class="field" data-field-label="预估开始时间"><label>预估开始时间 <span class="req">*</span></label><select name="start" id="start"></select></div>
      <div class="field" data-field-label="预估测试时长"><label>预估测试时长 <span class="req">*</span></label><div class="input-suffix"><input name="selfEst" type="number" min="30" step="30" value="120" required><span>分钟</span></div></div>
      <div class="field" data-field-label="意向机台"><label>意向机台 <span class="req">*</span></label><select name="machine" id="machine" required></select></div>
      <div class="field wide" data-field-label="排他机台"><label>排他机台</label><select name="excludedMachines" id="excluded-machines" multiple></select></div>
    </div>
    <div class="field-grid" data-mode-only="algo">
      <div class="field"><label>预估测试时长 <span class="req">*</span></label><div class="input-suffix"><input name="algoEst" type="number" min="30" step="30" value="180" required><span>分钟</span></div></div>
      <div class="field"><label>期望执行日期 <span class="req">*</span></label><select name="algoDay"><option value="0">今晚</option><option value="1">明晚</option></select></div>
      <div class="field"><label>优先级</label><select name="prio"><option value="mid">中 · 常规</option><option value="high">高 · 关键 / 阻塞</option><option value="low">低 · 有空档即可</option></select></div>
    </div>
  </section>`;

  const noteSection = `<section class="form-block" data-mode-only="algo" data-step="04">
    <div class="block-head"><div><span>04</span><h2>补充信息</h2></div><small>选填</small></div>
    <div class="field-grid"><div class="field wide"><label>备注</label><textarea name="note" placeholder="治具、测试条件或特殊要求"></textarea></div><div class="field wide"><label>附件</label><input type="file" multiple></div></div>
  </section>`;

  const summary = `<div class="live-summary">
    <span>当前工单</span><strong data-summary-product>待选择产品</strong><p data-summary-schedule>白班 · 今天 · 08:00</p>
  </div>`;

  const actions = `<div class="form-actions"><a class="btn" href="index.html">取消</a><button class="btn primary" type="submit" id="submit">${V2App.I.plus}提交预约</button></div>`;

  function renderLayout() {
    const layouts = {
      1: `<form id="showcase-form" class="flow-surface">${modeSwitch}${identity}${objectSection}${requirementSection}${scheduleSection}${noteSection}${actions}</form>`,
      2: `<form id="showcase-form" class="rail-layout"><aside class="form-rail">${modeSwitch}${identity}<ol><li class="active">测试对象</li><li data-mode-only="algo">测试要求</li><li>排程信息</li><li data-mode-only="algo">补充信息</li></ol></aside><div class="rail-main">${objectSection}${requirementSection}${scheduleSection}${noteSection}${actions}</div></form>`,
      3: `<form id="showcase-form"><div class="split-top">${modeSwitch}${identity}</div><div class="split-layout"><div class="split-main">${objectSection}${requirementSection}${noteSection}</div><aside class="split-schedule">${scheduleSection}${summary}${actions}</aside></div></form>`,
      4: `<form id="showcase-form" class="compact-surface"><div class="compact-top">${modeSwitch}${identity}</div><div class="compact-content">${objectSection}${requirementSection}${scheduleSection}${noteSection}</div>${actions}</form>`,
      5: `<form id="showcase-form" class="canvas-form"><div class="canvas-toolbar">${modeSwitch}${identity}</div>${objectSection}${requirementSection}${scheduleSection}${noteSection}<div class="canvas-bottom">${summary}${actions}</div></form>`
    };
    document.getElementById('create-app').innerHTML = `${pageHead}${variantNav}${layouts[variant]}`;
  }

  function setText(id, value) {
    document.getElementById(id).textContent = value;
  }

  function fillOptions() {
    const machines = Store.schedulableMachines();
    const machineOptions = machines.map(machine => `<option value="${machine.id}">${machine.name} · ${machine.type} · ${machine.lab}</option>`).join('');
    document.getElementById('machine').innerHTML = machineOptions;
    document.getElementById('excluded-machines').innerHTML = machineOptions;

    const selfDays = [0, 1, 2, 3].filter(day => Store.mode(day, 'day').kind === 'self');
    document.getElementById('day').innerHTML = selfDays.map(day => `<option value="${day}">${Store.dateLabel(day).text} · ${Store.dayName(day)}</option>`).join('');

    let times = '';
    for (let offset = 0; offset <= 690; offset += 30) {
      times += `<option value="${offset}">${Store.minToClock(offset)}</option>`;
    }
    document.getElementById('start').innerHTML = times;
  }

  function renderQuota() {
    const department = Store.department(currentDept);
    const day = Number(document.getElementById('day').value || 0);
    const used = Store.quotaUsedMin(currentDept, day);
    document.getElementById('quota').innerHTML = `<strong>${currentDept}</strong><span>${Store.dayName(day)}已用 ${used} / ${department.dailyQuotaMin} 分钟 · 剩余 ${Math.max(0, department.dailyQuotaMin - used)} 分钟</span>`;
  }

  function normalizeTemperature(value) {
    const normalized = value.trim().replace(/°C$/i, '℃');
    if (!normalized) return '';
    return /℃$/.test(normalized) ? normalized : `${normalized}℃`;
  }

  function addTemperatureRow(value = '') {
    const row = document.createElement('div');
    row.className = 'temperature-row';
    row.innerHTML = `<input name="temperatures" type="text" value="${value}" placeholder="手动填写温度，如 25℃"><button class="btn small" type="button" data-remove-temperature>删除</button>`;
    row.querySelector('[data-remove-temperature]').addEventListener('click', () => {
      row.remove();
      if (!document.querySelector('.temperature-row')) addTemperatureRow();
    });
    document.getElementById('temperature-rows').appendChild(row);
    if (activeMode === 'self') row.querySelector('input').disabled = true;
  }

  function updateSummary() {
    const form = document.getElementById('showcase-form');
    const product = form.elements.model.value || '待选择产品';
    const isSelf = activeMode === 'self';
    document.querySelectorAll('[data-summary-product]').forEach(element => { element.textContent = product; });
    const schedule = isSelf
      ? `白班 · ${Store.dayName(Number(form.elements.day.value || 0))} · ${Store.minToClock(Number(form.elements.start.value || 0))}`
      : `夜班 · ${form.elements.algoDay.selectedOptions[0].textContent} · 算法排程`;
    document.querySelectorAll('[data-summary-schedule]').forEach(element => { element.textContent = schedule; });
  }

  function setMode(mode) {
    activeMode = mode;
    const isSelf = activeMode === 'self';
    document.querySelectorAll('[data-mode]').forEach(button => button.classList.toggle('active', button.dataset.mode === activeMode));
    document.querySelectorAll('[data-mode-only]').forEach(element => {
      const visible = element.dataset.modeOnly === activeMode;
      element.hidden = !visible;
      element.querySelectorAll('input,select,textarea').forEach(control => { control.disabled = !visible; });
    });
    document.querySelectorAll('[data-schedule-step]').forEach(element => { element.textContent = isSelf ? '02' : '03'; });
    document.getElementById('mode-chip').textContent = isSelf ? '白班自助预约' : '算法统一排程';
    document.getElementById('submit').innerHTML = `${V2App.I.plus}${isSelf ? '提交预约' : '提交需求'}`;
    updateSummary();
  }

  function submitForm(event) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const isSelf = activeMode === 'self';
    const estimatedDuration = Number(formData.get(isSelf ? 'selfEst' : 'algoEst'));
    const id = (isSelf ? 'R-' : 'T-') + Math.floor(6000 + Math.random() * 3000);
    const baseTask = {
      id,
      pe: currentUser,
      dept: currentDept,
      product: formData.get('model'),
      type: formData.get('type'),
      purpose: formData.get('purpose'),
      est: estimatedDuration,
      status: isSelf ? 'scheduled' : 'pending'
    };

    if (isSelf) {
      const preferredMachine = formData.get('machine');
      const excludedMachines = formData.getAll('excludedMachines');
      if (excludedMachines.includes(preferredMachine)) {
        V2App.toast('意向机台不能同时设为排他机台', 'warn');
        return;
      }
      const start = Number(formData.get('start'));
      Store.addTask({ ...baseTask, day: Number(formData.get('day')), shift: 'day', machine: preferredMachine, preferredMachine, excludedMachines, start, end: start + estimatedDuration, prio: 'mid', source: 'self', checkedIn: false });
    } else {
      const temperatures = [...new Set(formData.getAll('temperatures').map(normalizeTemperature).filter(Boolean))];
      if (temperatures.length === 0) {
        V2App.toast('请至少添加一个测试温度', 'warn');
        return;
      }
      Store.addTask({ ...baseTask, day: Number(formData.get('algoDay')), shift: 'night', machine: null, start: null, end: null, prio: formData.get('prio'), serial: formData.get('serial'), batch: formData.get('batch'), qty: Number(formData.get('qty')), lab: formData.get('lab'), temps: temperatures, temperature: temperatures.join('、'), program: formData.get('program'), splitBin: formData.get('bin'), note: formData.get('note') || '' });
      Store.autoSchedule(id);
    }
    if (isOfficial) {
      V2App.toast(`${id} 已创建，正在返回排测中心`);
      setTimeout(() => { location.href = `index.html?focus=${id}`; }, 650);
    } else if (isDesignPreview) {
      V2App.toast(`${id} 已创建，可继续比较另一个设计方案`);
    } else {
      V2App.toast(`${id} 已创建，可继续比较其他方案`);
    }
  }

  V2App.mount('');
  renderLayout();
  setText('pe', currentUser);
  setText('dept', currentDept);
  fillOptions();
  renderQuota();
  addTemperatureRow();
  document.getElementById('temperature-add').addEventListener('click', () => addTemperatureRow());
  document.querySelectorAll('[data-mode]').forEach(button => button.addEventListener('click', () => setMode(button.dataset.mode)));
  document.getElementById('day').addEventListener('change', () => { renderQuota(); updateSummary(); });
  document.getElementById('showcase-form').addEventListener('change', updateSummary);
  document.getElementById('showcase-form').addEventListener('submit', submitForm);
  setMode('self');
})();