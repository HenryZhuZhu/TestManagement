(function(global){
  const S=global.Store;
  const I={
    plus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
    close:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    left:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 5l-7 7 7 7"/></svg>',
    right:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>',
    search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>',
    check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg>',
    chart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19V9M10 19V5M16 19v-7M22 19H2"/></svg>'
  };
  const NAV=[['index.html','排测中心'],['machines.html','机台'],['analytics.html','数据分析'],['settings.html','设置']];
  function mount(active){
    const role=S.role();
    document.body.insertAdjacentHTML('afterbegin',`<aside class="topbar"><div class="topbar-inner">
      <a class="brand" href="index.html"><span class="brand-mark">iT</span><span>iTest 智能排测</span></a>
      <nav class="nav">${NAV.map(n=>`<a class="${active===n[0]?'active':''}" href="${n[0]}">${n[1]}</a>`).join('')}</nav>
      <div class="top-actions"><button class="icon-btn" title="通知">◉</button><label class="user-menu" title="原型演示身份"><span class="avatar">${role.who.slice(0,1)}</span><select id="demo-role" style="border:0;background:transparent;outline:0"><option value="pe" ${role.key==='pe'?'selected':''}>王伟 · PE</option><option value="manager" ${role.key==='manager'?'selected':''}>主管 · 管理者</option><option value="lab" ${role.key==='lab'?'selected':''}>黄工 · Lab</option></select></label></div>
    </div></aside>`);
    document.getElementById('demo-role').addEventListener('change',e=>{S.setRole(e.target.value);location.reload()});
  }
  function status(t){const m=S.STATUS_META[t.status];return `<span class="status ${t.status}"><i></i>${m.label}</span>`}
  function priority(t){const m=S.PRIO_META[t.prio];return `<span class="priority ${t.prio}">${m.label}</span>`}
  function machineName(t){return t.machine?(S.machine(t.machine)?.name||t.machine):'待分配'}
  function toast(text,kind='success'){
    let wrap=document.querySelector('.toast-wrap');if(!wrap){wrap=document.createElement('div');wrap.className='toast-wrap';document.body.appendChild(wrap)}
    const el=document.createElement('div');el.className='toast '+kind;el.textContent=text;wrap.appendChild(el);setTimeout(()=>el.remove(),2600);
  }
  function ensureDrawer(){
    if(document.getElementById('drawer'))return;
    document.body.insertAdjacentHTML('beforeend','<div class="drawer-mask" id="drawer-mask"></div><aside class="drawer" id="drawer"><div id="drawer-content"></div></aside>');
    document.getElementById('drawer-mask').addEventListener('click',closeDrawer);
    document.addEventListener('keydown',e=>{if(e.key==='Escape')closeDrawer()});
  }
  function openDrawer(html){ensureDrawer();document.getElementById('drawer-content').innerHTML=html;document.getElementById('drawer').classList.add('open');document.getElementById('drawer-mask').classList.add('open');document.querySelectorAll('[data-close-drawer]').forEach(b=>b.addEventListener('click',closeDrawer))}
  function closeDrawer(){document.getElementById('drawer')?.classList.remove('open');document.getElementById('drawer-mask')?.classList.remove('open')}
  function taskDrawer(t,onChange){
    const role=S.role();const own=t.pe===S.CURRENT_PE;const m=t.machine?S.machine(t.machine):null;
    const actions=[];
    if(role.key==='pe'&&own&&t.shift==='day'&&t.status==='scheduled'&&t.checkedIn===false)actions.push('<button class="btn primary" data-action="checkin">到点签到</button>');
    if(role.key==='pe'&&own&&['pending','scheduled'].includes(t.status))actions.push('<button class="btn" data-action="edit">编辑工单</button>');
    if(role.key==='manager'&&!S.state.meta.managerAdjustUsed&&t.prio!=='high'&&['pending','scheduled'].includes(t.status))actions.push('<button class="btn primary" data-action="bump">提优</button>');
    if(role.key==='lab'&&t.shift==='night')actions.push('<button class="btn primary" data-action="start">'+(t.status==='running'?'完成测试':'开始测试')+'</button><button class="btn" data-action="reassign">改派机台</button>');
    openDrawer(`<div class="drawer-head"><div><h2>${t.id}</h2><div class="muted">工单详情</div></div><button class="icon-btn" data-close-drawer>${I.close}</button></div>
      <div class="drawer-body"><div class="detail-hero"><strong>${t.product}</strong><span class="muted">${t.type} · ${t.pe} · ${t.dept}</span></div>
      <dl class="kv"><dt>状态</dt><dd>${status(t)}</dd><dt>日期/班次</dt><dd>${S.dateLabel(t.day||0).text} · ${t.shift==='day'?'白班':'夜班'}</dd><dt>机台</dt><dd>${m?m.name+' · '+m.lab:'待算法分配'}</dd><dt>计划时间</dt><dd>${t.start!=null?S.minToClock(t.start)+'–'+S.minToClock(t.end):'待规划'}</dd><dt>预估时长</dt><dd>${S.fmtDur(t.est)}</dd><dt>优先级</dt><dd>${priority(t)}</dd><dt>备注</dt><dd>${t.note||'—'}</dd></dl>
      <h3 class="section-title">进度记录</h3><div class="timeline-list"><div class="timeline-item"><b>工单已提交</b><span>申请人 ${t.pe}</span></div><div class="timeline-item"><b>${t.machine?'系统已完成排程':'等待可用机台'}</b><span>${t.machine?machineName(t)+' · '+S.minToClock(t.start):'系统将持续尝试排入空档'}</span></div>${t.moved?'<div class="timeline-item"><b>Lab 已现场改派</b><span>当前机台 '+machineName(t)+'</span></div>':''}</div></div>
      <div class="drawer-foot"><button class="btn" data-close-drawer>关闭</button>${actions.join('')}</div>`);
    const done=()=>{closeDrawer();onChange&&onChange()};
    document.querySelector('[data-action="checkin"]')?.addEventListener('click',()=>{S.checkIn(t.id);toast('签到成功，测试已开始');done()});
    document.querySelector('[data-action="bump"]')?.addEventListener('click',()=>{S.setTaskPrio(t.id,t.prio==='low'?'mid':'high');S.useManagerAdjust(t.id);toast('已提优，排程视图已更新');done()});
    document.querySelector('[data-action="start"]')?.addEventListener('click',()=>{S.setTaskStatus(t.id,t.status==='running'?'done':'running');toast(t.status==='done'?'测试完成，已反馈 PE':'测试已开始');done()});
    document.querySelector('[data-action="edit"]')?.addEventListener('click',()=>{toast('编辑入口已统一收口到工单详情');});
    document.querySelector('[data-action="reassign"]')?.addEventListener('click',()=>{const target=S.schedulableMachines().find(x=>x.id!==t.machine);if(target){S.setTaskMachine(t.id,target.id);toast('已改派至 '+target.name);done()}});
  }
  global.V2App={I,mount,status,priority,machineName,toast,openDrawer,closeDrawer,taskDrawer};
})(window);
