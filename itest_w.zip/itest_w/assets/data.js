/* ============================================================
   iTest 智能排测系统 — shared mock data + state layer
   Persisted to localStorage so edits flow across pages.
   Time model: timeline offset 0 = 08:00; 1440 min span = 08:00→next 08:00
     Day shift   白班 : offset    0 – 720   (08:00 – 20:00)
     Night shift 夜班 : offset  720 – 1440  (20:00 – 08:00)
   ============================================================ */
(function (global) {
  const KEY = 'itest-state-v2';

  // simulated "current time": 14:40 → day shift in progress
  const NOW_MIN = 400;

  const SEED = {
    nowMin: NOW_MIN,
    today: '2026-06-10',
    meta: {
      // PE manager: one priority bump per day, for a single task
      managerAdjustUsed: false,
      managerAdjustTask: null,
    },
    machines: [
      { id: 'M-01', name: 'ICT-A',  type: 'ICT 在线测试',  lab: 'A区·01', status: 'idle',        owner: '—',        note: '' },
      { id: 'M-02', name: 'ICT-B',  type: 'ICT 在线测试',  lab: 'A区·02', status: 'running',     owner: '陈明',     note: '正在执行 T-1004' },
      { id: 'M-03', name: 'FCT-A',  type: 'FCT 功能测试',  lab: 'A区·05', status: 'running',     owner: '王伟',     note: '正在执行 T-1006' },
      { id: 'M-04', name: 'FCT-B',  type: 'FCT 功能测试',  lab: 'A区·06', status: 'maintenance', owner: '设备组',   note: '探针更换保养，预计 18:00 恢复' },
      { id: 'M-05', name: 'RF-01',  type: '射频测试',      lab: 'B区·11', status: 'idle',        owner: '—',        note: '' },
      { id: 'M-06', name: 'BURN-01',type: '老化测试',      lab: 'B区·14', status: 'fault',       owner: '设备组',   note: '温箱压缩机异常，待维修，暂停排测' },
    ],
    tasks: [
      // ---------- 白班 day shift ----------
      { id: 'T-1001', shift: 'day',   machine: 'M-01', start: 0,   end: 120, status: 'done',
        pe: '王伟', dept: '研发一部', product: 'Apollo 主板', type: 'ICT', prio: 'mid', est: 120, note: '良率 99.2%，已上传报告' },
      { id: 'T-1002', shift: 'day',   machine: 'M-01', start: 150, end: 330, status: 'done',
        pe: '李娜', dept: '研发一部', product: 'Orion 模组', type: 'ICT', prio: 'mid', est: 180, note: '' },
      { id: 'T-1003', shift: 'day',   machine: 'M-02', start: 60,  end: 240, status: 'done',
        pe: '张涛', dept: '研发二部', product: 'Vega 子板', type: 'ICT', prio: 'low', est: 180, note: '' },
      { id: 'T-1004', shift: 'day',   machine: 'M-02', start: 270, end: 510, status: 'running',
        pe: '陈明', dept: '研发二部', product: 'Apollo 主板', type: 'ICT', prio: 'high', est: 240, note: '' },
      { id: 'T-1005', shift: 'day',   machine: 'M-03', start: 30,  end: 360, status: 'done',
        pe: '刘洋', dept: '研发一部', product: 'Nova 整机', type: 'FCT', prio: 'mid', est: 330, note: '' },
      { id: 'T-1006', shift: 'day',   machine: 'M-03', start: 360, end: 600, status: 'running',
        pe: '王伟', dept: '研发一部', product: 'Orion 模组', type: 'FCT', prio: 'high', est: 240, note: '' },
      { id: 'T-1007', shift: 'day',   machine: 'M-05', start: 420, end: 600, status: 'scheduled',
        pe: '赵敏', dept: '研发三部', product: 'Pulsar 射频板', type: 'RF', prio: 'mid', est: 180, note: '' },

      // ---------- 夜班 night shift（PE 白班提交，Lab 工程师夜间执行）----------
      { id: 'T-2001', shift: 'night', machine: 'M-01', start: 720,  end: 900,  status: 'scheduled',
        pe: '李娜', dept: '研发一部', product: 'Orion 模组', type: 'ICT', prio: 'high', est: 180, note: '' },
      { id: 'T-2002', shift: 'night', machine: 'M-01', start: 930,  end: 1110, status: 'scheduled',
        pe: '王伟', dept: '研发一部', product: 'Apollo 主板', type: 'ICT', prio: 'mid', est: 180, note: '' },
      { id: 'T-2003', shift: 'night', machine: 'M-02', start: 750,  end: 1020, status: 'scheduled',
        pe: '陈明', dept: '研发二部', product: 'Vega 子板', type: 'ICT', prio: 'mid', est: 270, note: '' },
      { id: 'T-2004', shift: 'night', machine: 'M-03', start: 780,  end: 1200, status: 'scheduled',
        pe: '刘洋', dept: '研发一部', product: 'Nova 整机', type: 'FCT', prio: 'high', est: 420, note: '夜间长时间老化+功能复测' },
      { id: 'T-2005', shift: 'night', machine: 'M-05', start: 720,  end: 1140, status: 'scheduled',
        pe: '赵敏', dept: '研发三部', product: 'Pulsar 射频板', type: 'RF', prio: 'low', est: 420, note: '' },

      // ---------- 待排程 pending（智能算法待规划 / 机台不可用导致挂起）----------
      { id: 'T-2006', shift: 'night', machine: null, start: null, end: null, status: 'pending',
        pe: '张涛', dept: '研发二部', product: 'Quasar 电源板', type: '老化', prio: 'mid', est: 360, note: 'BURN-01 故障，等待机台恢复或改派' },
      { id: 'T-2007', shift: 'day',   machine: null, start: null, end: null, status: 'pending',
        pe: '周琳', dept: '研发三部', product: 'Comet 传感模组', type: 'FCT', prio: 'high', est: 150, note: '今日新提交，待算法插入白班空档' },

      // ---------- 明日规划 day +1（算法已提前排好）----------
      { id: 'T-1101', day: 1, shift: 'day',   machine: 'M-01', start: 60,  end: 210,  status: 'scheduled',
        pe: '王伟', dept: '研发一部', product: 'Apollo 主板', type: 'ICT', prio: 'mid', est: 150, note: '明日首件复测' },
      { id: 'T-1102', day: 1, shift: 'day',   machine: 'M-02', start: 30,  end: 240,  status: 'scheduled',
        pe: '李娜', dept: '研发一部', product: 'Orion 模组', type: 'ICT', prio: 'high', est: 210, note: '' },
      { id: 'T-1103', day: 1, shift: 'day',   machine: 'M-03', start: 120, end: 420,  status: 'scheduled',
        pe: '刘洋', dept: '研发一部', product: 'Nova 整机', type: 'FCT', prio: 'mid', est: 300, note: '' },
      { id: 'T-1104', day: 1, shift: 'day',   machine: 'M-05', start: 300, end: 480,  status: 'scheduled',
        pe: '赵敏', dept: '研发三部', product: 'Pulsar 射频板', type: 'RF', prio: 'low', est: 180, note: '' },
      { id: 'T-2101', day: 1, shift: 'night', machine: 'M-01', start: 720, end: 960,  status: 'scheduled',
        pe: '王伟', dept: '研发一部', product: 'Apollo 主板', type: 'ICT', prio: 'high', est: 240, note: '夜间老化 + 功能复测' },
      { id: 'T-2102', day: 1, shift: 'night', machine: 'M-03', start: 780, end: 1140, status: 'scheduled',
        pe: '陈明', dept: '研发二部', product: 'Vega 子板', type: 'ICT', prio: 'mid', est: 360, note: '' },
    ],
  };

  // ---- persistence ----
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    const s = clone(SEED);
    save(s);
    return s;
  }
  function save(s) {
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {}
  }

  let state = load();

  // ---- helpers ----
  function minToClock(offset) {
    if (offset == null) return '—';
    let total = 480 + offset;
    const h = Math.floor(total / 60) % 24;
    const m = total % 60;
    return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
  }
  function fmtDur(min) {
    if (min == null) return '—';
    const h = Math.floor(min / 60), m = min % 60;
    return (h ? h + 'h' : '') + (m ? m + 'min' : (h ? '' : '0min'));
  }
  // date label for a day-offset relative to the simulated "today" (state.today)
  function dateLabel(offset) {
    const base = new Date(state.today + 'T00:00:00');
    const d = new Date(base.getTime() + offset * 86400000);
    const wd = ['周日','周一','周二','周三','周四','周五','周六'][d.getDay()];
    const text = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    return { text, wd, isToday: offset === 0 };
  }
  function dayName(offset) {
    return offset === 0 ? '今天' : offset === 1 ? '明天' : offset === -1 ? '昨天'
         : (offset > 0 ? '+' + offset + '天' : offset + '天');
  }

  const STATUS_META = {
    pending:   { label: '待排程',  cls: 'neutral' },
    scheduled: { label: '已排程',  cls: 'info' },
    running:   { label: '测试中',  cls: 'running' },
    done:      { label: '已完成',  cls: 'ok' },
    hold:      { label: '已挂起',  cls: 'warn' },
    fail:      { label: '测试异常', cls: 'danger' },
  };
  const MACHINE_STATUS = {
    idle:        { label: '空闲',   cls: 'ok',      schedulable: true  },
    running:     { label: '运行中', cls: 'running', schedulable: true  },
    maintenance: { label: '保养中', cls: 'warn',    schedulable: false },
    fault:       { label: '故障',   cls: 'danger',  schedulable: false },
  };
  const PRIO_META = {
    high: { label: '高', cls: 'p-high', rank: 0 },
    mid:  { label: '中', cls: 'p-mid',  rank: 1 },
    low:  { label: '低', cls: 'p-low',  rank: 2 },
  };

  const Store = {
    get state() { return state; },
    get machines() { return state.machines; },
    get tasks() { return state.tasks; },
    nowMin: () => state.nowMin,
    today: () => state.today,

    machine(id) { return state.machines.find(m => m.id === id); },
    task(id) { return state.tasks.find(t => t.id === id); },
    tasksByShift(shift) { return state.tasks.filter(t => t.shift === shift); },
    schedulableMachines() { return state.machines.filter(m => MACHINE_STATUS[m.status].schedulable); },

    setMachineStatus(id, status, note) {
      const m = this.machine(id);
      if (!m) return;
      m.status = status;
      if (note != null) m.note = note;
      save(state);
    },
    setTaskStatus(id, status, note) {
      const t = this.task(id);
      if (!t) return;
      t.status = status;
      if (note != null) t.note = note;
      save(state);
    },
    setTaskMachine(id, machine) {
      const t = this.task(id);
      if (!t) return;
      t.machine = machine;
      t.moved = true;
      save(state);
    },
    setTaskPrio(id, prio) {
      const t = this.task(id);
      if (!t) return;
      t.prio = prio;
      save(state);
    },
    addTask(t) {
      state.tasks.push(t);
      save(state);
    },
    updateTask(id, fields) {
      const t = this.task(id);
      if (!t) return;
      Object.assign(t, fields);
      save(state);
    },
    removeTask(id) {
      const i = state.tasks.findIndex(t => t.id === id);
      if (i >= 0) state.tasks.splice(i, 1);
      save(state);
    },
    // 智能排测算法（原型）：清空原占位，按班次/当天找最早空档重新分配。
    // 工程师无法指定机台或时间 —— 每次编辑都会重排，从机制上杜绝提前占位。
    autoSchedule(id) {
      const t = this.task(id);
      if (!t) return null;
      const day = t.day || 0;
      const [lo, hi] = this.SHIFT_RANGE[t.shift];
      // release current placement first
      t.machine = null; t.start = null; t.end = null;
      let best = null;
      for (const m of this.schedulableMachines()) {
        const occ = state.tasks.filter(x => x.id !== id && x.machine === m.id && x.start != null
                      && (x.day || 0) === day && x.shift === t.shift).sort((a, b) => a.start - b.start);
        let cursor = lo;
        if (day === 0 && t.shift === 'day') cursor = Math.max(cursor, state.nowMin); // 不排到过去
        for (const o of occ) { if (o.start - cursor >= t.est) break; cursor = Math.max(cursor, o.end); }
        if (cursor + t.est <= hi && (!best || cursor < best.start)) best = { machine: m.id, start: cursor };
      }
      if (best) { t.machine = best.machine; t.start = best.start; t.end = best.start + t.est; t.status = 'scheduled'; }
      else { t.status = 'pending'; }
      save(state);
      return best;
    },
    useManagerAdjust(taskId) {
      state.meta.managerAdjustUsed = true;
      state.meta.managerAdjustTask = taskId;
      save(state);
    },
    persist() { save(state); },
    reset() { localStorage.removeItem(KEY); state = load(); },

    minToClock, fmtDur, dateLabel, dayName,
    STATUS_META, MACHINE_STATUS, PRIO_META,
    SHIFT_RANGE: { day: [0, 720], night: [720, 1440] },
    CURRENT_PE: '王伟',   // the logged-in PE engineer (for the「我的」filter)
  };

  global.Store = Store;
})(window);
